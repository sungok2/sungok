plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "netshare.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "org.example.netsharep2p.conditional"
        minSdk = 33
        targetSdk = 33
        versionCode = 12
        versionName = "0.12.0-ux-dashboard"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    sourceSets.getByName("main").java {
        srcDir("../core/src/main/kotlin")
        srcDir("../android-adapter/src/main/java")
    }
}
