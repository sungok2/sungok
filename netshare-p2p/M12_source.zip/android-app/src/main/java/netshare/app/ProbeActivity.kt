package netshare.app

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import java.net.Inet4Address
import netshare.android.CellularSelector
import netshare.core.ClientAddressPolicy

/**
 * M12 human-friendly, read-only P2P dashboard. Does not create, join, or remove P2P groups.
 * The conditional proxy remains guarded by service-side role and independent attestation.
 */
@Suppress("DEPRECATION")
class ProbeActivity : Activity() {
    private object Palette {
        val background = Color.rgb(8, 18, 31)
        val panel = Color.rgb(19, 38, 57)
        val secondaryPanel = Color.rgb(27, 50, 70)
        val accent = Color.rgb(69, 225, 191)
        val accentDark = Color.rgb(16, 76, 71)
        val light = Color.rgb(242, 249, 255)
        val muted = Color.rgb(172, 193, 211)
        val yellow = Color.rgb(255, 204, 117)
        val red = Color.rgb(255, 151, 160)
        val line = Color.rgb(51, 74, 94)
    }

    private enum class Role { UNKNOWN, ABSENT, GROUP_OWNER, GROUP_CLIENT }
    private enum class Scan { NOT_STARTED, STARTING, STARTED, FAILED }

    private lateinit var stateText: TextView
    private lateinit var localIpText: EditText
    private lateinit var clientIpText: EditText
    private lateinit var attested: CheckBox
    private lateinit var startButton: Button
    private lateinit var statusHeadline: TextView
    private lateinit var statusDescription: TextView
    private lateinit var statusTag: TextView
    private lateinit var permissionStep: TextView
    private lateinit var connectionStep: TextView
    private lateinit var discoveryStep: TextView
    private lateinit var proxyStep: TextView
    private lateinit var peerInfo: TextView
    private lateinit var technicalDetails: LinearLayout
    private lateinit var technicalToggle: Button

    private var observedRole = Role.UNKNOWN
    private var observedOwnerIp: Inet4Address? = null
    private var inspectionGeneration = 0
    private var cellularReady = false
    private var scan = Scan.NOT_STARTED
    private var peerCount = -1
    private var detailsExpanded = false
    private val nearbyRequestCode = 6012
    private val uiHandler = Handler(Looper.getMainLooper())
    private lateinit var sounds: UiFeedback

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun box(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun label(value: String, sp: Float = 14f, color: Int = Palette.light, weight: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = sp
            setTextColor(color)
            if (weight) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setLineSpacing(dp(3).toFloat(), 1f)
        }

    private fun vbox(gapTop: Int = 0): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        if (gapTop > 0) setPadding(0, dp(gapTop), 0, 0)
    }

    private fun LinearLayout.add(node: View, top: Int = 0) {
        addView(node, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) })
    }

    private fun panel(): LinearLayout = vbox().apply {
        background = box(Palette.panel)
        setPadding(dp(20), dp(20), dp(20), dp(20))
    }

    private fun action(text: String, filled: Boolean, description: String = text): Button =
        Button(this).apply {
            this.text = text
            textSize = 14f
            isAllCaps = false
            setTextColor(if (filled) Palette.background else Palette.light)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            minHeight = dp(54)
            minimumHeight = dp(54)
            background = RippleDrawable(
                ColorStateList.valueOf(if (filled) Palette.accentDark else Palette.line),
                box(if (filled) Palette.accent else Palette.secondaryPanel, 14), null
            )
            contentDescription = description
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

    private fun sectionTitle(index: String, name: String, subtitle: String): LinearLayout =
        vbox().apply {
            add(label("$index  $name", 19f, Palette.light, true))
            add(label(subtitle, 12.5f, Palette.muted), 5)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        setTheme(android.R.style.Theme_Material_NoActionBar)
        super.onCreate(savedInstanceState)
        window.statusBarColor = Palette.background
        window.navigationBarColor = Palette.background
        window.decorView.systemUiVisibility = 0
        sounds = UiFeedback(this)

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(Palette.background)
            clipToPadding = false
        }
        val main = vbox().apply {
            setPadding(dp(18), dp(22), dp(18), dp(35))
        }
        scroll.addView(main)

        val brand = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brandLeft = vbox().apply {
            add(label("NETSHARE  /  LAB", 11f, Palette.accent, true))
            add(label("연결 준비 센터", 26f, Palette.light, true), 5)
        }
        brand.addView(brandLeft, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val soundSwitch = Switch(this).apply {
            text = "효과음"
            textSize = 12f
            setTextColor(Palette.muted)
            isChecked = sounds.enabled
            contentDescription = "효과음 켜기 또는 끄기"
            setOnCheckedChangeListener { _, checked ->
                sounds.enabled = checked
                if (checked) sounds.play(UiFeedback.Cue.SUCCESS)
            }
        }
        brand.addView(soundSwitch)
        main.add(brand)
        main.add(label("Wi-Fi Direct 상태를 확인하고, 가능한 작업만 안내합니다.", 13f, Palette.muted), 10)

        val hero = panel().apply {
            background = box(Palette.accentDark, 20, Palette.accent)
        }
        statusTag = label("●  연결 전", 12f, Palette.accent, true)
        statusHeadline = label("P2P 연결 대기", 23f, Palette.light, true)
        statusDescription = label("Wi-Fi Direct 연결이 만들어지지 않았습니다. 먼저 기기 검색과 연결 상태를 확인하세요.", 13f, Palette.muted)
        hero.add(statusTag)
        hero.add(statusHeadline, 8)
        hero.add(statusDescription, 9)
        main.add(hero, 22)

        val journey = panel()
        journey.add(label("현재 진행 단계", 16f, Palette.light, true))
        permissionStep = label("① 근처 기기 권한  ·  확인 전", 13f, Palette.muted)
        journey.add(permissionStep, 12)
        discoveryStep = label("② 기기 검색  ·  실행 전", 13f, Palette.muted)
        connectionStep = label("③ P2P 연결  ·  확인 전", 13f, Palette.muted)
        proxyStep = label("④ 프록시  ·  조건 미충족", 13f, Palette.muted)
        journey.add(discoveryStep, 8)
        journey.add(connectionStep, 8)
        journey.add(proxyStep, 8)
        main.add(journey, 14)

        val discovery = panel()
        discovery.add(sectionTitle("01", "연결 상태 확인", "기기 검색과 실제 연결은 서로 다릅니다."))
        val refresh = action("연결 상태 새로고침", true,
            "Wi-Fi Direct 그룹과 기기 역할 및 IP 주소를 다시 확인")
        refresh.setOnClickListener {
            sounds.play(UiFeedback.Cue.TAP)
            inspectWithPermission()
        }
        discovery.add(refresh, 15)
        val scanButton = action("주변 Wi-Fi Direct 기기 검색", false,
            "주변 Wi-Fi Direct 기기만 검색, 연결 또는 그룹 생성하지 않음")
        scanButton.setOnClickListener {
            sounds.play(UiFeedback.Cue.TAP)
            scanP2pPeers()
        }
        discovery.add(scanButton, 9)
        val peersButton = action("검색된 기기 목록 보기", false)
        peersButton.setOnClickListener { sounds.play(UiFeedback.Cue.TAP); readP2pPeers() }
        discovery.add(peersButton, 9)
        peerInfo = label("검색된 기기: 아직 조회하지 않았습니다.", 13f, Palette.muted)
        discovery.add(peerInfo, 13)
        discovery.add(label("주의: 검색만으로 연결되지 않습니다. 이 앱은 새 P2P 그룹이나 테더링을 실행하지 않습니다.", 12f, Palette.yellow), 12)
        main.add(discovery, 16)

        val help = panel()
        help.add(sectionTitle("02", "다음에 할 일", "화면에 IPv4가 없으면 프록시를 실행할 수 없습니다."))
        help.add(label("A. 주변 기기를 검색합니다.\nB. 외부에서 이미 구성된 P2P 링크에 이 갤럭시가 Group Client로 참여한 경우에만 연결 상태를 다시 조회합니다.\nC. 역할·주소·셀룰러 상태를 확인한 후 조건부 프록시를 검토합니다.",
            13f, Palette.light), 13)
        val settingsButton = action("Wi-Fi 설정 열기", false)
        settingsButton.setOnClickListener {
            sounds.play(UiFeedback.Cue.TAP)
            try { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) }
            catch (e: Exception) { log("Wi-Fi 설정 열기 실패: ${e.javaClass.simpleName}"); sounds.play(UiFeedback.Cue.WARNING) }
        }
        help.add(settingsButton, 13)
        help.add(label("표준 그룹 생성이 Android 내부 Tethering을 호출하지 않는다는 보증은 없습니다. 이 화면에서 임의 연결을 권장하지 않습니다.",
            12f, Palette.yellow), 13)
        main.add(help, 16)

        val advanced = panel()
        technicalToggle = action("고급 진단 · 프록시 설정 펼치기  ▾", false)
        technicalToggle.contentDescription = "고급 기술 진단과 조건부 프록시 설정 펼치기"
        advanced.add(technicalToggle)
        technicalDetails = vbox(13).apply { visibility = View.GONE }
        technicalToggle.setOnClickListener {
            sounds.play(UiFeedback.Cue.TAP)
            detailsExpanded = !detailsExpanded
            technicalDetails.visibility = if (detailsExpanded) View.VISIBLE else View.GONE
            technicalToggle.text = if (detailsExpanded) "고급 진단 · 프록시 설정 접기  ▴" else "고급 진단 · 프록시 설정 펼치기  ▾"
            technicalToggle.contentDescription = technicalToggle.text
        }
        technicalDetails.add(label("전문가용 연결 진단", 17f, Palette.light, true), 5)
        stateText = label("조회 전입니다. '연결 상태 새로고침'을 눌러주세요.", 12f, Palette.muted).apply {
            setTextIsSelectable(true)
            setPadding(dp(13), dp(13), dp(13), dp(13))
            background = box(Palette.background, 12)
            contentDescription = "Wi-Fi Direct 상세 진단 로그"
        }
        technicalDetails.add(stateText, 4)
        val copy = action("진단 로그 복사", false)
        copy.setOnClickListener {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("NetShare P2P M12 진단", stateText.text.toString()))
            sounds.play(UiFeedback.Cue.SUCCESS)
            log("진단 결과 복사 완료")
        }
        technicalDetails.add(copy, 4)
        technicalDetails.add(label("프록시의 실제 수신 주소", 13f, Palette.light, true))
        localIpText = EditText(this).apply {
            hint = "연결된 GC의 P2P IPv4"
            setHintTextColor(Palette.muted)
            setTextColor(Palette.light)
            textSize = 15f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            background = box(Palette.secondaryPanel, 10)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            minimumHeight = dp(51)
        }
        technicalDetails.add(localIpText, 4)
        technicalDetails.add(label("연결 허용할 상대 기기 IPv4", 13f, Palette.light, true))
        clientIpText = EditText(this).apply {
            hint = "GO의 IPv4 (확인된 경우 자동 입력)"
            setHintTextColor(Palette.muted)
            setTextColor(Palette.light)
            textSize = 15f
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
            background = box(Palette.secondaryPanel, 10)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            minimumHeight = dp(51)
        }
        technicalDetails.add(clientIpText, 4)
        val inputsChanged = object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateStatus() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        }
        localIpText.addTextChangedListener(inputsChanged)
        clientIpText.addTextChangedListener(inputsChanged)
        attested = CheckBox(this).apply {
            text = "별도의 실기기·펌웨어 검증을 통해 이 링크에서 Android Tethering, SoftAP, Hotspot이 사용되지 않음을 확인했습니다."
            textSize = 12.5f
            setTextColor(Palette.light)
            isChecked = false
            setOnCheckedChangeListener { _, _ -> updateStatus() }
        }
        technicalDetails.add(attested)
        technicalDetails.add(label("검증하지 않았다면 체크하지 마세요. 앱은 시스템 내부 동작을 증명할 수 없습니다.", 12f, Palette.yellow))
        startButton = action("조건부 프록시 시작 · 8282", true)
        startButton.setOnClickListener {
            if (canStart()) { sounds.play(UiFeedback.Cue.SUCCESS); startProxyIfConfirmed() }
            else { sounds.play(UiFeedback.Cue.WARNING); log("시작 불가: GC 역할·활성 P2P IPv4·셀룰러·외부 적합성 확인이 필요합니다.") }
        }
        technicalDetails.add(startButton, 4)
        val statusButton = action("최근 실행 상태 확인", false)
        statusButton.setOnClickListener { sounds.play(UiFeedback.Cue.TAP); log(ServiceStatus.read(this@ProbeActivity)) }
        technicalDetails.add(statusButton, 4)
        val stopButton = action("프록시 중지", false)
        stopButton.setOnClickListener {
            stopService(Intent(this@ProbeActivity, ProxyService::class.java))
            sounds.play(UiFeedback.Cue.TAP)
            log("프록시 중지 요청 전송")
        }
        technicalDetails.add(stopButton, 4)
        advanced.add(technicalDetails)
        main.add(advanced, 16)
        main.add(label("M12 · 안전 진단 빌드 · 앱 내부 금지 API 정적 검사와 단말 내부 동작의 실증은 다릅니다.",
            11f, Palette.muted), 20)

        setContentView(scroll)
        updateStatus()
    }

    private fun log(line: String) {
        val next = (stateText.text.toString() + "\n" + line).takeLast(9000)
        stateText.text = next
    }

    private fun hasNearbyPermission(): Boolean = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) == PackageManager.PERMISSION_GRANTED

    private fun canStart(): Boolean {
        if (observedRole != Role.GROUP_CLIENT || !cellularReady || !attested.isChecked || !hasNearbyPermission()) return false
        val local = P2pNetworkInspector.parseIPv4(localIpText.text.toString()) ?: return false
        val client = P2pNetworkInspector.parseIPv4(clientIpText.text.toString()) ?: return false
        return local != client && ClientAddressPolicy.isUsableClient(client) &&
            P2pNetworkInspector.activeP2pIPv4().any { it.address == local }
    }

    private fun updateStatus() {
        val localIp = P2pNetworkInspector.activeP2pIPv4().firstOrNull()?.address?.hostAddress
        val ready = canStart()
        val (tag, headline, description, tone) = when {
            observedRole == Role.GROUP_OWNER -> arrayOf(
                "●  안전 차단", "현재 기기: Group Owner", "GO 경로는 금지 조건의 충족 여부를 입증하지 못하므로 프록시 실행을 차단합니다.", "red")
            ready -> arrayOf(
                "●  조건부 실행 가능", "필요 조건 확인", "별도 링크 검증 확인 후에만 프록시를 실행할 수 있습니다. 실제 인터넷 공유는 미검증입니다.", "green")
            observedRole == Role.GROUP_CLIENT && localIp != null -> arrayOf(
                "●  GC 연결 확인", "P2P 연결 감지됨", "GC 주소: $localIp. 외부 적합성 확인과 상대 IP 검증은 별도입니다.", "green")
            observedRole == Role.GROUP_CLIENT -> arrayOf(
                "●  IP 할당 대기", "그룹은 있으나 IPv4 없음", "GC 역할을 확인했지만 인터페이스 IPv4가 할당되지 않았습니다.", "yellow")
            else -> arrayOf(
                "●  연결 전", "P2P 연결 대기", "근처 기기 검색은 가능하지만 실제 P2P 그룹과 IPv4가 확인되지 않았습니다.", "yellow")
        }
        statusTag.text = tag
        statusTag.setTextColor(when (tone) { "red" -> Palette.red; "green" -> Palette.accent; else -> Palette.yellow })
        statusHeadline.text = headline
        statusDescription.text = description
        statusHeadline.accessibilityLiveRegion = View.ACCESSIBILITY_LIVE_REGION_POLITE
        permissionStep.text = if (hasNearbyPermission()) "① 근처 기기 권한  ·  허용됨" else "① 근처 기기 권한  ·  허용 필요"
        discoveryStep.text = when (scan) {
            Scan.NOT_STARTED -> "② 기기 검색  ·  실행 전"
            Scan.STARTING -> "② 기기 검색  ·  검색 요청 중"
            Scan.STARTED -> "② 기기 검색  ·  검색 시작됨${if (peerCount >= 0) " ($peerCount 대 발견)" else ""}"
            Scan.FAILED -> "② 기기 검색  ·  실패, 진단 확인"
        }
        connectionStep.text = when (observedRole) {
            Role.GROUP_CLIENT -> "③ P2P 연결  ·  Group Client 확인${if (localIp == null) ", IP 없음" else ""}"
            Role.GROUP_OWNER -> "③ P2P 연결  ·  Group Owner (차단)"
            Role.ABSENT -> "③ P2P 연결  ·  그룹 없음"
            Role.UNKNOWN -> "③ P2P 연결  ·  확인 전"
        }
        proxyStep.text = if (ready) "④ 프록시  ·  조건부 실행 가능" else "④ 프록시  ·  안전 차단 중"
        startButton.isEnabled = ready
        startButton.alpha = if (ready) 1f else 0.45f
        startButton.contentDescription = if (ready) "조건부 프록시 실행" else "프록시 실행 불가: 링크 검증 조건 미충족"
    }

    private fun inspectWithPermission() {
        if (!hasNearbyPermission()) {
            log("근처 기기 권한을 허용한 후 다시 조회합니다.")
            requestPermissions(arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES), nearbyRequestCode)
            return
        }
        inspectReadOnly()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != nearbyRequestCode) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            sounds.play(UiFeedback.Cue.SUCCESS)
            inspectReadOnly()
        } else {
            log("권한 거부: 근처 Wi-Fi 기기 접근 권한이 필요합니다.")
            sounds.play(UiFeedback.Cue.WARNING)
            updateStatus()
        }
    }

    private fun inspectReadOnly() {
        val generation = ++inspectionGeneration
        observedRole = Role.UNKNOWN
        observedOwnerIp = null
        localIpText.setText("")
        clientIpText.setText("")
        cellularReady = CellularSelector.select(this) != null
        val ipList = P2pNetworkInspector.activeP2pIPv4()
        val lines = mutableListOf<String>()
        lines += "기기=${Build.MODEL}; Android API=${Build.VERSION.SDK_INT}"
        lines += "Wi-Fi Direct 지원=${packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)}"
        lines += "NEARBY_WIFI_DEVICES=${hasNearbyPermission()}"
        lines += "CHANGE_WIFI_STATE=${checkSelfPermission(Manifest.permission.CHANGE_WIFI_STATE) == PackageManager.PERMISSION_GRANTED}"
        lines += "셀룰러 Network 검증=$cellularReady"
        lines += "활성 P2P IPv4=${if (ipList.isEmpty()) "없음" else ipList.joinToString { "${it.interfaceName}=${it.address.hostAddress}" }}"
        lines += "주의: 그룹 존재만으로 Tethering 미사용을 증명할 수 없습니다."
        stateText.text = lines.joinToString("\n")
        updateStatus()

        val manager = getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
        if (manager == null) { log("Wi-Fi P2P 서비스 없음"); return }
        val channel = try { manager.initialize(this, mainLooper, null) }
        catch (e: Exception) { log("P2P 초기화 실패: ${e.javaClass.simpleName} ${e.message.orEmpty().take(150)}"); return }
        if (channel == null) { log("P2P 채널 생성 실패"); return }

        try {
            manager.requestP2pState(channel) { state ->
                if (generation == inspectionGeneration) {
                    log("Wi-Fi Direct 활성=${state == WifiP2pManager.WIFI_P2P_STATE_ENABLED}")
                }
            }
        } catch (e: Exception) { log("P2P 활성 조회 실패: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(150)}") }

        try {
            manager.requestConnectionInfo(channel) { info ->
                if (generation != inspectionGeneration) return@requestConnectionInfo
                when {
                    info == null || !info.groupFormed -> log("연결 정보: 그룹 미형성")
                    info.isGroupOwner -> log("연결 정보: Galaxy가 Group Owner")
                    else -> {
                        val ip = info.groupOwnerAddress as? Inet4Address
                        observedOwnerIp = ip?.takeIf { ClientAddressPolicy.isUsableClient(it) }
                        log("연결 정보: Galaxy는 Group Client, 상대 GO=${ip?.hostAddress ?: "알 수 없음"}")
                        fillFromGroupClient()
                    }
                }
            }
        } catch (e: Exception) { log("연결 정보 조회 실패: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(150)}") }

        try {
            manager.requestGroupInfo(channel) { group ->
                if (generation != inspectionGeneration) return@requestGroupInfo
                observedRole = when {
                    group == null -> Role.ABSENT
                    group.isGroupOwner -> Role.GROUP_OWNER
                    else -> Role.GROUP_CLIENT
                }
                log(if (group == null) "기존 P2P 그룹: 없음" else
                    "기존 그룹: $observedRole, interface=${group.getInterface()}, clients=${group.clientList.size}")
                if (observedRole == Role.GROUP_CLIENT) fillFromGroupClient()
                updateStatus()
            }
        } catch (e: Exception) { log("그룹 조회 실패: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(180)}") }
    }

    private fun scanP2pPeers() {
        if (!hasNearbyPermission()) {
            log("검색 전 근처 기기 접근 권한을 승인하세요.")
            requestPermissions(arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES), nearbyRequestCode)
            return
        }
        scan = Scan.STARTING
        peerInfo.text = "검색 요청 중 · 검색은 연결이 아닙니다."
        updateStatus()
        val manager = getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
        if (manager == null) { failedScan("P2P 서비스 없음"); return }
        try {
            val channel = manager.initialize(this, mainLooper, null)
            if (channel == null) { failedScan("채널 초기화 실패"); return }
            manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    scan = Scan.STARTED
                    log("기기 검색 시작됨. 그룹 연결 요청은 수행하지 않았습니다.")
                    peerInfo.text = "검색 시작됨 · 잠시 후 발견 목록을 확인합니다."
                    sounds.play(UiFeedback.Cue.SUCCESS)
                    updateStatus()
                    uiHandler.postDelayed({ readP2pPeers() }, 4000L)
                }
                override fun onFailure(reason: Int) { failedScan("검색 거절: 코드 $reason (1=P2P_UNSUPPORTED, 2=BUSY)") }
            })
        } catch (e: Exception) { failedScan("기기 검색 실패: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(150)}") }
    }

    private fun failedScan(message: String) {
        scan = Scan.FAILED
        peerInfo.text = "검색 실패 · 고급 진단에서 상세 내용을 확인하세요."
        log(message)
        sounds.play(UiFeedback.Cue.WARNING)
        updateStatus()
    }

    private fun readP2pPeers() {
        if (!hasNearbyPermission()) { log("근처 기기 권한이 필요합니다."); return }
        val manager = getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
        if (manager == null) { log("검색 목록 조회 불가: 서비스 없음"); return }
        try {
            val channel = manager.initialize(this, mainLooper, null)
            if (channel == null) { log("검색 목록 조회 불가: 채널 없음"); return }
            manager.requestPeers(channel) { peers ->
                val devices = peers?.deviceList.orEmpty().toList()
                peerCount = devices.size
                if (devices.isEmpty()) {
                    peerInfo.text = "검색된 기기가 없습니다. 상대 기기의 Wi-Fi Direct 활성 여부를 확인하세요."
                } else {
                    peerInfo.text = "검색된 기기 ${devices.size}대 (연결된 기기는 아님)\n" +
                        devices.take(8).joinToString("\n") { "• " + it.deviceName.orEmpty().replace('\n', ' ').take(35).ifBlank { "이름 없는 기기" } }
                    sounds.play(UiFeedback.Cue.SUCCESS)
                }
                log("검색 결과 ${devices.size}대: 그룹 연결 상태와 별개")
                updateStatus()
            }
        } catch (e: Exception) { log("검색 목록 조회 실패: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(150)}") }
    }

    private fun fillFromGroupClient() {
        if (observedRole != Role.GROUP_CLIENT) return
        val local = P2pNetworkInspector.activeP2pIPv4().singleOrNull()?.address
        if (local != null) localIpText.setText(local.hostAddress)
        observedOwnerIp?.let { clientIpText.setText(it.hostAddress) }
        log(if (local == null) "Group Client 확인, IPv4는 아직 없습니다." else
            "프록시 주소 후보: ${local.hostAddress}:8282 (접속 가능성 미검증)")
        updateStatus()
    }

    private fun startProxyIfConfirmed() {
        if (!canStart()) {
            log("실행 거절: 현재 GC 역할·P2P IPv4·셀룰러·외부 적합성 확인 조건이 충족되지 않았습니다.")
            sounds.play(UiFeedback.Cue.WARNING)
            return
        }
        val local = P2pNetworkInspector.parseIPv4(localIpText.text.toString())!!
        val client = P2pNetworkInspector.parseIPv4(clientIpText.text.toString())!!
        try {
            startForegroundService(Intent(this, ProxyService::class.java)
                .setAction(ProxyService.ACTION_START)
                .putExtra(ProxyService.EXTRA_LISTEN_IP, local.hostAddress)
                .putExtra(ProxyService.EXTRA_CLIENT_IP, client.hostAddress)
                .putExtra(ProxyService.EXTRA_OPERATOR_ATTESTED, true))
            log("조건부 프록시 시작 요청. 실행 여부는 서비스 상태에서 확인하세요.")
        } catch (e: Exception) {
            log("시작 실패: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(150)}")
            sounds.play(UiFeedback.Cue.WARNING)
        }
    }

    override fun onDestroy() {
        ++inspectionGeneration
        uiHandler.removeCallbacksAndMessages(null)
        sounds.release()
        super.onDestroy()
    }
}
