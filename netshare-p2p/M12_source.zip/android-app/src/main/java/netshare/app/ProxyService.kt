package netshare.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.net.wifi.p2p.WifiP2pManager
import android.net.Network
import android.os.Handler
import java.util.concurrent.atomic.AtomicBoolean
import java.net.Inet4Address
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import netshare.android.CellularSelector
import netshare.android.CellularUpstreamConnector
import netshare.core.ClientAddressPolicy
import netshare.core.ProxyCore
import netshare.core.P2pRole
import netshare.core.P2pRolePolicy
import netshare.core.RuntimeSafetyPolicy

/**
 * Conditional proxy over an *already existing* P2P address.
 * NEVER creates a group, changes networking, invokes Android Tethering or SoftAP.
 * An existing group is NOT in itself proof of compliance. Operator must supply external evidence.
 */
class ProxyService : Service() {
    private var proxy: ProxyCore? = null
    // Invalidate pending asynchronous group-info callbacks on STOP or service destruction.
    private var requestGeneration: Int = 0
    private val notificationId = 8282
    private val channelId = "proxy_state"
    private val safetyHandler by lazy { Handler(mainLooper) }
    private var activeListenAddress: Inet4Address? = null
    private var activeCellularNetwork: Network? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(
            NotificationChannel(channelId, "P2P 프록시 상태", NotificationManager.IMPORTANCE_LOW))
    }

    /**
     * Fail closed: a phone acting as Wi-Fi Direct Group Owner would pass through the
     * AOSP Tethering-managed IP-serving code path. This conditional proxy ONLY
     * accepts a device acting as Group Client; that is necessary but NOT sufficient
     * to prove that the entire link avoids tethering on the remote device.
     */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            requestGeneration++
            stopSelf()
            return START_NOT_STICKY
        }
        if (proxy != null) return START_NOT_STICKY
        startForeground(notificationId, makeNotification("P2P 역할 확인 중"))
        ServiceStatus.write(this, "P2P 그룹 역할 확인 중")
        val thisRequest = ++requestGeneration
        if (intent?.action != ACTION_START ||
            !intent.getBooleanExtra(EXTRA_OPERATOR_ATTESTED, false)) {
            reject("Link compliance has not been independently attested", startId)
            return START_NOT_STICKY
        }
        val manager = getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
        if (manager == null) {
            reject("WifiP2pManager not available", startId)
            return START_NOT_STICKY
        }
        try {
            val channel = manager.initialize(this, mainLooper, null)
            if (channel == null) {
                reject("Cannot initialize read-only Wi-Fi P2P observer", startId)
                return START_NOT_STICKY
            }
            val completed = AtomicBoolean(false)
            val handler = Handler(mainLooper)
            val timeout = Runnable {
                if (thisRequest == requestGeneration && completed.compareAndSet(false, true))
                    reject("Group role query timeout", startId)
            }
            handler.postDelayed(timeout, 5_000L)
            manager.requestGroupInfo(channel) { group ->
                if (thisRequest == requestGeneration && completed.compareAndSet(false, true)) {
                    handler.removeCallbacks(timeout)
                    val role = when {
                        group == null -> P2pRole.ABSENT
                        group.isGroupOwner -> P2pRole.GROUP_OWNER
                        else -> P2pRole.GROUP_CLIENT
                    }
                    if (!P2pRolePolicy.canStart(role, linkIndependentlyVerified = true)) {
                        reject("P2P role rejected: $role (GO Tethering path is disallowed)", startId)
                    } else startProxyOnExistingGroupClient(intent, startId, manager, channel, thisRequest)
                }
            }
        } catch (e: Exception) {
            reject("P2P group role query failed: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(180)}", startId)
        }
        return START_NOT_STICKY
    }

    private fun startProxyOnExistingGroupClient(
        intent: Intent, startId: Int,
        manager: WifiP2pManager, channel: WifiP2pManager.Channel, generation: Int
    ) {
        try {
            val localIp = P2pNetworkInspector.parseIPv4(intent.getStringExtra(EXTRA_LISTEN_IP).orEmpty())
                ?: throw IllegalArgumentException("Bad numeric local IPv4")
            val clientIp = P2pNetworkInspector.parseIPv4(intent.getStringExtra(EXTRA_CLIENT_IP).orEmpty())
                ?: throw IllegalArgumentException("Bad numeric client IPv4")
            if (localIp == clientIp || !ClientAddressPolicy.isUsableClient(clientIp)) {
                throw IllegalArgumentException("Unsafe client IPv4")
            }
            if (P2pNetworkInspector.activeP2pIPv4().none { it.address == localIp }) {
                throw IllegalArgumentException("P2P interface/address not active")
            }
            val cellular = CellularSelector.select(this)
                ?: throw IllegalStateException("Validated cellular network not available")
            val server = ProxyCore(localIp, 8282, CellularUpstreamConnector(this, cellular),
                allowedClient = { incoming -> incoming == clientIp &&
                    P2pNetworkInspector.activeP2pIPv4().any { it.address == localIp } },
                maxClients = 16)
            val port = server.start()
            proxy = server
            activeListenAddress = localIp
            activeCellularNetwork = cellular
            // Periodic fail-closed observation only: no P2P creation or network reconfiguration.
            scheduleSafetyCheck(manager, channel, generation)
            ServiceStatus.write(this, "실행 중 · 포트 $port · 셀룰러 전용 · 안전 감시 활성")
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(
                notificationId, makeNotification("${localIp.hostAddress}:$port / 허용: ${clientIp.hostAddress}"))
        } catch (e: Exception) {
            reject("Proxy start rejected: ${e.javaClass.simpleName}", startId)
        }
    }

    /**
     * Runtime guard. Checking GC at startup is not enough if the group disappears,
     * the role changes, the interface is removed, or the selected cellular network
     * becomes unavailable. Failure to observe the state is treated as unsafe.
     * This DOES NOT establish that the device firmware is tethering-free.
     */
    private fun scheduleSafetyCheck(
        manager: WifiP2pManager, channel: WifiP2pManager.Channel, generation: Int
    ) {
        safetyHandler.postDelayed(Runnable {
            if (generation != requestGeneration || proxy == null) return@Runnable
            val finished = AtomicBoolean(false)
            val timeout = Runnable {
                if (generation == requestGeneration && finished.compareAndSet(false, true)) {
                    stopForSafety("P2P group monitor timed out")
                }
            }
            safetyHandler.postDelayed(timeout, 5_000L)
            try {
                manager.requestGroupInfo(channel) { group ->
                    if (generation != requestGeneration || !finished.compareAndSet(false, true)) {
                        return@requestGroupInfo
                    }
                    safetyHandler.removeCallbacks(timeout)
                    // Any monitoring exception is a shutdown condition, not permission
                    // to continue proxying with unverified interface/egress state.
                    val safeToContinue = try {
                        val listen = activeListenAddress
                        val p2pStillUp = listen != null &&
                            P2pNetworkInspector.activeP2pIPv4().any { it.address == listen }
                        val sameCellular = activeCellularNetwork != null &&
                            CellularSelector.select(this) == activeCellularNetwork
                        val observedRole = when {
                            group == null -> P2pRole.ABSENT
                            group.isGroupOwner -> P2pRole.GROUP_OWNER
                            else -> P2pRole.GROUP_CLIENT
                        }
                        RuntimeSafetyPolicy.mayKeepRunning(observedRole, p2pStillUp, sameCellular)
                    } catch (_: Exception) { false }
                    if (!safeToContinue) {
                        stopForSafety("P2P Group Client, interface or cellular state changed")
                    } else {
                        scheduleSafetyCheck(manager, channel, generation)
                    }
                }
            } catch (e: Exception) {
                safetyHandler.removeCallbacks(timeout)
                if (generation == requestGeneration && finished.compareAndSet(false, true)) {
                    stopForSafety("P2P monitor failed: ${e.javaClass.simpleName}")
                }
            }
        }, 6_000L)
    }

    private fun stopForSafety(reason: String) {
        requestGeneration++
        proxy?.close()
        proxy = null
        activeListenAddress = null
        activeCellularNetwork = null
        ServiceStatus.write(this, "안전 종료: $reason")
        Log.w("NetShareP2P", "Fail closed: $reason")
        stopSelf()
    }

    private fun reject(reason: String, startId: Int) {
        // Cancel stale asynchronous callbacks before allowing the service to stop.
        requestGeneration++
        Log.w("NetShareP2P", reason)
        ServiceStatus.write(this, "실행 거부: $reason")
        stopSelf(startId)
    }

    private fun makeNotification(message: String): Notification {
        val stopIntent = Intent(this, ProxyService::class.java).setAction(ACTION_STOP)
        val pending = PendingIntent.getService(this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("P2P Proxy · 그룹 생성 없음")
            .setContentText(message)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(null, "종료", pending).build())
            .build()
    }

    override fun onDestroy() {
        requestGeneration++
        safetyHandler.removeCallbacksAndMessages(null)
        proxy?.close()
        proxy = null
        activeListenAddress = null
        activeCellularNetwork = null
        if (ServiceStatus.read(this).startsWith("실행 중")) ServiceStatus.write(this, "정상 종료")
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "netshare.app.START_PROXY"
        const val ACTION_STOP = "netshare.app.STOP_PROXY"
        const val EXTRA_LISTEN_IP = "listen_ip"
        const val EXTRA_CLIENT_IP = "client_ip"
        const val EXTRA_OPERATOR_ATTESTED = "p2p_compliance_attested"
    }
}
