package netshare.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool

/** Three original, short, low-volume interface sounds. Respects mute choice and phone silent mode. */
class UiFeedback(context: Context) {
    enum class Cue { TAP, SUCCESS, WARNING }
    private val appContext = context.applicationContext
    private val preferences = appContext.getSharedPreferences("netshare_ux", Context.MODE_PRIVATE)
    private val audioManager = appContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val pool = SoundPool.Builder().setMaxStreams(2)
        .setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()).build()
    private val loaded = mutableSetOf<Int>()
    private val ids: Map<Cue, Int>

    init {
        pool.setOnLoadCompleteListener { _, sampleId, status ->
            if (status == 0) synchronized(loaded) { loaded.add(sampleId) }
        }
        ids = mapOf(
            Cue.TAP to pool.load(appContext, R.raw.ui_tap, 1),
            Cue.SUCCESS to pool.load(appContext, R.raw.ui_success, 1),
            Cue.WARNING to pool.load(appContext, R.raw.ui_warning, 1)
        )
    }

    var enabled: Boolean
        get() = preferences.getBoolean("sound_enabled", true)
        set(value) { preferences.edit().putBoolean("sound_enabled", value).apply() }

    fun play(cue: Cue) {
        if (!enabled || audioManager.ringerMode != AudioManager.RINGER_MODE_NORMAL) return
        val id = ids[cue] ?: return
        if (!synchronized(loaded) { loaded.contains(id) }) return
        val volume = when (cue) { Cue.TAP -> 0.22f; Cue.SUCCESS -> 0.34f; Cue.WARNING -> 0.28f }
        pool.play(id, volume, volume, 1, 0, 1.0f)
    }

    fun release() { pool.release() }
}
