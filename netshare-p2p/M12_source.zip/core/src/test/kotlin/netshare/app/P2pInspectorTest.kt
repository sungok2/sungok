package netshare.app

/** Pure JVM tests for numeric IPv4 parsing. No Android P2P device involved. */
fun main() {
    val valid = listOf("192.168.49.1", "10.0.0.7", "255.255.255.255")
    val invalid = listOf("", "abc", "127.0.0", "192.168.49.256", "192.168.49.-1",
        "192.168.049.1", "192.168.49.1 ", "2001:db8::1", "1.2.3.4.5")
    valid.forEach { value ->
        check(P2pNetworkInspector.parseIPv4(value)?.hostAddress == value) { "Valid: $value" }
        println("PASS: numeric IPv4 parsed $value")
    }
    invalid.forEach { value ->
        check(P2pNetworkInspector.parseIPv4(value) == null) { "Invalid: $value" }
        println("PASS: malformed IPv4 rejected '$value'")
    }
    println("TOTAL INSPECTOR PASS: ${valid.size + invalid.size}")
}
