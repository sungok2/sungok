package netshare.core

import java.net.InetAddress

fun main() {
    val rejected = listOf("0.0.0.0", "127.0.0.1", "169.254.12.2", "10.1.2.3", "172.16.0.1",
        "192.168.49.1", "100.64.0.1", "198.18.0.1", "192.0.2.9", "198.51.100.2",
        "203.0.113.7", "224.0.0.1", "255.255.255.255", "::1", "fe80::1", "fc00::1", "2001:db8::1")
    val accepted = listOf("1.1.1.1", "8.8.8.8", "9.9.9.9", "2001:4860:4860::8888", "64:ff9b::808:808")
    var passes = 0
    for (ip in rejected) {
        check(!EgressAddressPolicy.isAllowed(InetAddress.getByName(ip))) { "Allowed prohibited address $ip" }
        passes++
    }
    for (ip in accepted) {
        check(EgressAddressPolicy.isAllowed(InetAddress.getByName(ip))) { "Rejected intended public address $ip" }
        passes++
    }
    println("TOTAL EGRESS ADDRESS POLICY PASS: $passes")
}
