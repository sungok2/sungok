package netshare.core

import java.net.InetAddress
import java.net.Socket

/** JVM-only regression: sending a byte repeatedly must not defeat the header deadline. */
fun main() {
    val loop = InetAddress.getLoopbackAddress()
    val unusedUpstream = UpstreamConnector { _, _ -> error("Never connect upstream for incomplete headers") }
    ProxyCore(loop, 0, unusedUpstream, { it.isLoopbackAddress },
        headerBudgetMillis = 225).use { proxy ->
        Socket(loop, proxy.start()).use { client ->
            client.soTimeout = 2500
            val out = client.getOutputStream()
            // Each individual delay is shorter than the idle budget, but their
            // combined time exceeds the entire allowed header parsing budget.
            for (c in "GET ") {
                try { out.write(c.code); out.flush() } catch (_: java.io.IOException) { break }
                Thread.sleep(85)
            }
            val line = client.getInputStream().bufferedReader().readLine()
            check(line.startsWith("HTTP/1.1 408 ")) { "Expected 408, got $line" }
        }
    }
    println("PASS M6: Slow-drip request rejected by overall header deadline")
}
