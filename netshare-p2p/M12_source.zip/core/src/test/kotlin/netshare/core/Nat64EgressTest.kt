package netshare.core

import java.net.InetAddress

/** Address-only tests: network-specific NAT64 prefix originates from Android LinkProperties. */
fun main() {
    fun ip(s: String) = InetAddress.getByName(s)
    val prefix = ip("2001:db9:9999:8888:7777:6666::")
    val cases = listOf(
        Triple("64:ff9b::c0a8:0101", false, "WK NAT64 private"),
        Triple("64:ff9b::0808:0808", true, "WK NAT64 public"),
        Triple("64:ff9b::7f00:0001", false, "WK NAT64 loopback"),
        Triple("2002:0808:0808::", false, "6to4 fail-closed"),
        Triple("2001:0000::1", false, "Teredo fail-closed"),
        Triple("2001:4860:4860::8888", true, "Public IPv6"),
        Triple("192.168.1.1", false, "Private IPv4"),
        Triple("8.8.8.8", true, "Public IPv4"),
    )
    var count = 0
    for ((addr, expected, description) in cases) {
        val actual = EgressAddressPolicy.isAllowed(ip(addr))
        check(actual == expected) { "$description: $addr -> $actual, expected $expected" }
        count++
    }
    val privateDynamic = ip("2001:db9:9999:8888:7777:6666:c0a8:0101")
    val publicDynamic = ip("2001:db9:9999:8888:7777:6666:0808:0808")
    check(!EgressAddressPolicy.isAllowed(privateDynamic, prefix, 96)); count++
    check(EgressAddressPolicy.isAllowed(publicDynamic, prefix, 96)); count++
    println("TOTAL NAT64 EGRESS TEST PASS: $count")
}
