package netshare.core

fun main() {
    var passed = 0
    for (role in P2pRole.entries) {
        for (verified in listOf(false, true)) {
            val expected = role == P2pRole.GROUP_CLIENT && verified
            check(P2pRolePolicy.canStart(role, verified) == expected)
            println("PASS: role=$role, independentEvidence=$verified -> $expected")
            passed++
        }
    }
    println("TOTAL P2P ROLE POLICY PASS: $passed")
}
