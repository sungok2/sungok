package netshare.core

import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/** Plain JVM executable assertions; no JUnit or Android SDK required. */
fun main() {
    val loop = InetAddress.getLoopbackAddress()
    val connector = UpstreamConnector { host, port -> Socket(host, port) }
    var passes = 0
    fun checkCase(name: String, input: String, startsWith: String) {
        ProxyCore(loop, 0, connector, { it.isLoopbackAddress }).use { p ->
            Socket(loop, p.start()).use { sock ->
                sock.soTimeout = 3000
                sock.getOutputStream().write(input.toByteArray(Charsets.ISO_8859_1))
                sock.getOutputStream().flush()
                val read = sock.getInputStream().bufferedReader().readLine()
                check(read.startsWith(startsWith)) { "$name: expected $startsWith, got $read" }
            }
        }
        println("PASS: $name")
        passes++
    }
    checkCase("reject LF-only", "GET / HTTP/1.1\n\n", "HTTP/1.1 400")
    checkCase("reject invalid origin-form", "GET /x HTTP/1.1\r\nHost: localhost\r\n\r\n", "HTTP/1.1 400")
    checkCase("reject HTTPS absolute-form without CONNECT", "GET https://example.org/ HTTP/1.1\r\n\r\n", "HTTP/1.1 400")
    checkCase("reject unsupported TRACE", "TRACE http://example.org/ HTTP/1.1\r\n\r\n", "HTTP/1.1 501")
    checkCase("reject duplicated content length", "GET http://example.org/ HTTP/1.1\r\nContent-Length: 0\r\nContent-Length: 0\r\n\r\n", "HTTP/1.1 400")
    checkCase("reject transfer encoding", "GET http://example.org/ HTTP/1.1\r\nTransfer-Encoding: chunked\r\n\r\n", "HTTP/1.1 400")
    checkCase("reject request body", "GET http://example.org/ HTTP/1.1\r\nContent-Length: 5\r\n\r\n", "HTTP/1.1 400")
    checkCase("reject malformed CONNECT authority", "CONNECT example.org HTTP/1.1\r\n\r\n", "HTTP/1.1 400")
    checkCase("reject excessive first line", "GET http://example.org/${"x".repeat(5000)} HTTP/1.1\r\n\r\n", "HTTP/1.1 400")
    checkCase("reject header injection", "GET http://example.org/ HTTP/1.1\r\nX-Inj: hi\rhost\r\n\r\n", "HTTP/1.1 400")
    checkCase("reject invalid header token", "GET http://example.org/ HTTP/1.1\r\nBad Key: abc\r\n\r\n", "HTTP/1.1 400")

    val disconnected = UpstreamConnector { _, _ -> throw IOException("No cellular") }
    ProxyCore(loop, 0, disconnected, { it.isLoopbackAddress }).use { proxy ->
        Socket(loop, proxy.start()).use { socket ->
            socket.soTimeout = 3000
            socket.getOutputStream().write("CONNECT example.org:443 HTTP/1.1\r\n\r\n".toByteArray())
            check(socket.getInputStream().bufferedReader().readLine().startsWith("HTTP/1.1 502"))
        }
    }
    println("PASS: upstream failure fails closed"); passes++

    // Verify Hop-by-Hop header removal, not just basic GET forwarding.
    val target = ServerSocket(0, 1, loop)
    val targetThread = thread {
        target.accept().use { s ->
            s.soTimeout = 4000
            val br = s.getInputStream().bufferedReader()
            check(br.readLine() == "GET /resource HTTP/1.1")
            val lines = mutableListOf<String>()
            while (true) { val line = br.readLine(); if (line.isEmpty()) break; lines += line }
            check(lines.none { it.startsWith("X-Private:") || it.startsWith("Proxy-Authorization:") })
            check(lines.any { it == "Connection: close" })
            s.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nOK".toByteArray())
        }
    }
    ProxyCore(loop, 0, connector, { it.isLoopbackAddress }).use { proxy ->
        Socket(loop, proxy.start()).use { s ->
            s.soTimeout = 3000
            s.getOutputStream().write(("GET http://localhost:${target.localPort}/resource HTTP/1.1\r\n" +
                "Connection: X-Private\r\nX-Private: secret\r\nProxy-Authorization: secret\r\n\r\n").toByteArray())
            check(s.getInputStream().bufferedReader().readText().endsWith("OK"))
        }
    }
    targetThread.join(3000)
    check(!targetThread.isAlive)
    target.close()
    println("PASS: hop-by-hop headers removed"); passes++

    try { ProxyCore(InetAddress.getByName("0.0.0.0"), 0, connector); error("Expected failure") }
    catch (_: IllegalArgumentException) { println("PASS: wildcard bind prohibited"); passes++ }
    println("TOTAL EXTENDED PASS: $passes")
}
