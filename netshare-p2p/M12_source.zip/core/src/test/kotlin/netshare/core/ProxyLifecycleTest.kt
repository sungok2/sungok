package netshare.core

import java.io.IOException
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** Regression: stopping service must close active upstream CONNECT sockets. JVM-only. */
fun main() {
    val loop = InetAddress.getLoopbackAddress()
    val target = ServerSocket(0, 1, loop)
    val remoteAccepted = CountDownLatch(1)
    val remoteClosed = CountDownLatch(1)
    val remoteThread = thread(isDaemon = true) {
        try {
            target.accept().use { remote ->
                remote.soTimeout = 4_000
                remoteAccepted.countDown()
                try { while (remote.getInputStream().read() != -1) { } }
                catch (_: IOException) { }
                remoteClosed.countDown()
            }
        } catch (_: Exception) { }
    }
    val connector = UpstreamConnector { host, port -> Socket(host, port) }
    val proxy = ProxyCore(loop, 0, connector, { it.isLoopbackAddress })
    try {
        Socket(loop, proxy.start()).use { client ->
            client.soTimeout = 4_000
            client.getOutputStream().write(("CONNECT localhost:${target.localPort} HTTP/1.1\r\n" +
                "Host: localhost\r\n\r\n").toByteArray())
            val inStream = client.getInputStream()
            val bytes = StringBuilder()
            while (!bytes.endsWith("\r\n\r\n")) {
                val b = inStream.read()
                check(b >= 0) { "unexpected EOF in CONNECT response" }
                bytes.append(b.toChar())
                check(bytes.length <= 1000)
            }
            check(bytes.startsWith("HTTP/1.1 200"))
            check(remoteAccepted.await(2, TimeUnit.SECONDS))
            proxy.close()
            check(remoteClosed.await(3, TimeUnit.SECONDS)) { "proxy.close() left upstream tunnel open" }
            println("PASS: stopping proxy closes active CONNECT upstream socket")
        }
    } finally {
        proxy.close()
        target.close()
        remoteThread.join(1_000)
    }
}
