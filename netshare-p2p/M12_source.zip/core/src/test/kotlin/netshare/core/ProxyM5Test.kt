package netshare.core

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** JVM-only regression tests; deliberately not a Samsung/Android device test. */
fun main() {
    val loop = InetAddress.getLoopbackAddress()
    val upstream = UpstreamConnector { host, port -> Socket(host, port) }
    var passed = 0
    fun assertStatus(request: String, expected: Int) {
        ProxyCore(loop, 0, upstream, { it.isLoopbackAddress }).use { proxy ->
            Socket(loop, proxy.start()).use { client ->
                client.soTimeout = 3000
                client.getOutputStream().write(request.toByteArray(Charsets.ISO_8859_1))
                val response = client.getInputStream().bufferedReader().readLine()
                check(response.startsWith("HTTP/1.1 $expected ")) { "Expected $expected; got $response" }
            }
        }
        passed++
    }
    assertStatus("POST http://example.com/ HTTP/1.1\r\nContent-Length: -1\r\n\r\n", 400)
    assertStatus("POST http://example.com/ HTTP/1.1\r\nContent-Length: 8388609\r\n\r\n", 413)
    assertStatus("POST http://example.com/ HTTP/1.1\r\nContent-Length: one\r\n\r\n", 400)
    assertStatus("POST http://example.com/ HTTP/1.1\r\nContent-Length: +5\r\n\r\n", 400)
    assertStatus("POST http://example.com/ HTTP/1.1\r\nContent-Length: 5, 5\r\n\r\n", 400)
    assertStatus("POST http://example.com/ HTTP/1.1\r\nExpect: 100-continue\r\n\r\n", 417)
    assertStatus("POST http://example.com/ HTTP/1.1\r\nTransfer-Encoding: chunked\r\n\r\n", 400)
    assertStatus("CONNECT example.com:443 HTTP/1.1\r\nContent-Length: 1\r\n\r\n!", 400)
    assertStatus("GET http://example.com/ HTTP/1.1\r\nContent-Length: 1\r\n\r\n!", 400)

    val target = ServerSocket(0, 1, loop)
    val done = CountDownLatch(1)
    val serverError = arrayOfNulls<Throwable>(1)
    val worker = thread(isDaemon = true) {
        try {
            target.accept().use { socket ->
                socket.soTimeout = 4_000
                val source = BufferedInputStream(socket.getInputStream())
                fun line(): String {
                    val bytes = ByteArrayOutputStream()
                    while (true) {
                        val b = source.read()
                        check(b >= 0)
                        if (b == 10) return String(bytes.toByteArray(), Charsets.ISO_8859_1).removeSuffix("\r")
                        bytes.write(b)
                    }
                }
                check(line() == "POST /send?q=ok HTTP/1.1")
                var bodyLength = -1
                var hostCount = 0
                while (true) {
                    val header = line()
                    if (header.isEmpty()) break
                    if (header.startsWith("Content-Length:")) bodyLength = header.substringAfter(':').trim().toInt()
                    if (header.startsWith("Host:")) hostCount++
                    check(!header.startsWith("Proxy-Authorization:", true))
                }
                check(bodyLength == 5)
                check(hostCount == 1)
                val buffer = ByteArray(5)
                var read = 0
                while (read < buffer.size) { val n = source.read(buffer, read, buffer.size-read); check(n > 0); read += n }
                check(String(buffer) == "HELLO")
                socket.getOutputStream().write("HTTP/1.1 201 Created\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK".toByteArray())
            }
        } catch (e: Throwable) { serverError[0] = e }
        finally { done.countDown() }
    }
    ProxyCore(loop, 0, upstream, { it.isLoopbackAddress }).use { proxy ->
        Socket(loop, proxy.start()).use { socket ->
            socket.soTimeout = 5_000
            val request = "POST http://localhost:${target.localPort}/send?q=ok HTTP/1.1\r\n" +
                "Host: should-not-forward\r\nProxy-Authorization: secret\r\nContent-Length: 5\r\n\r\nHELLO"
            socket.getOutputStream().write(request.toByteArray())
            val result = socket.getInputStream().bufferedReader().readText()
            check(result.startsWith("HTTP/1.1 201 Created"))
            check(result.endsWith("OK"))
        }
    }
    check(done.await(5, TimeUnit.SECONDS))
    target.close()
    worker.join(1000)
    serverError[0]?.let { throw it }
    passed++

    val lifecycle = ProxyCore(loop, 0, upstream, { it.isLoopbackAddress })
    lifecycle.close()
    try {
        lifecycle.start()
        error("Restart after close must fail")
    } catch (_: IllegalStateException) { passed++ }

    println("TOTAL M5 PASS: $passed")
}
