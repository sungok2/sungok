package netshare.core

import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.InetAddress
import java.net.Socket

/** JVM only. Validates fail-closed response integrity without any external network access. */
fun main() {
    val loop = InetAddress.getLoopbackAddress()
    val partial = "HTTP/1.1 200 OK\r\nContent-Length: 100\r\n\r\nPARTIAL".toByteArray(Charsets.ISO_8859_1)

    // The remote sends some response bytes and then suffers an I/O failure.
    // A proxy must not append an HTTP/1.1 502 to the truncated HTTP 200 body.
    val connector = UpstreamConnector { _, _ ->
        object : Socket() {
            override fun getOutputStream() = ByteArrayOutputStream()
            override fun getInputStream(): InputStream = object : InputStream() {
                var consumed = false
                override fun read(): Int {
                    val b = ByteArray(1)
                    return if (read(b, 0, 1) < 0) -1 else b[0].toInt() and 255
                }
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    if (consumed) throw IOException("Injected failure after partial upstream response")
                    consumed = true
                    val n = minOf(len, partial.size)
                    System.arraycopy(partial, 0, b, off, n)
                    return n
                }
            }
        }
    }
    ProxyCore(loop, 0, connector, { it.isLoopbackAddress }).use { proxy ->
        Socket(loop, proxy.start()).use { client ->
            client.soTimeout = 3000
            client.getOutputStream().write("GET http://example.org/ HTTP/1.1\r\nHost: example.org\r\n\r\n".toByteArray())
            val result = ByteArrayOutputStream()
            val buffer = ByteArray(1024)
            while (true) {
                val n = client.getInputStream().read(buffer)
                if (n < 0) break
                result.write(buffer, 0, n)
            }
            val actual = result.toByteArray()
            check(actual.contentEquals(partial)) {
                "Partial upstream reply was modified; appended synthetic HTTP status or lost data: ${String(actual)}"
            }
        }
    }
    println("PASS M6: Partial upstream reply stays byte-identical, no appended synthetic HTTP status")
}
