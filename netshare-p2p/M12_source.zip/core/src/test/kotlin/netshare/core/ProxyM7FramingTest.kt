package netshare.core

import java.net.InetAddress
import java.net.Socket
import java.util.concurrent.atomic.AtomicInteger

/** Request-framing and hop-by-hop invariants, without external DNS/network access. */
fun main() {
    val loop = InetAddress.getLoopbackAddress()
    val upstreamCalls = AtomicInteger(0)
    val sink = UpstreamConnector { _, _ ->
        upstreamCalls.incrementAndGet()
        error("Must never contact upstream for invalid framing")
    }
    val rejected = listOf(
        "POST http://example.org/upload HTTP/1.1\r\nConnection: Content-Length\r\nContent-Length: 4\r\n\r\nTEST",
        "POST http://example.org/upload HTTP/1.1\r\nProxy-Connection: Content-Length\r\nContent-Length: 4\r\n\r\nTEST",
        "POST http://example.org/upload HTTP/1.1\r\nConnection: Host\r\nContent-Length: 4\r\n\r\nTEST",
        "POST http://example.org/upload HTTP/1.1\r\nConnection: Expect\r\nContent-Length: 4\r\n\r\nTEST",
        "POST http://example.org/upload HTTP/1.1\r\nConnection: foo,,bar\r\nContent-Length: 4\r\n\r\nTEST",
        "POST http://example.org/upload HTTP/1.1\r\nProxy-Connection: TE, Host\r\nContent-Length: 4\r\n\r\nTEST",
    )
    rejected.forEachIndexed { index, request ->
        ProxyCore(loop, 0, sink, { it.isLoopbackAddress }).use { proxy ->
            Socket(loop, proxy.start()).use { client ->
                client.soTimeout = 3_000
                client.getOutputStream().write(request.toByteArray(Charsets.ISO_8859_1))
                val response = client.getInputStream().bufferedReader().readLine()
                check(response.startsWith("HTTP/1.1 400 ")) { "Case $index: $response" }
            }
        }
        check(upstreamCalls.get() == 0) { "Upstream contacted for invalid case $index" }
    }
    println("PASS M7 framing: ${rejected.size} malformed/unsafe connection token requests rejected before upstream")
}
