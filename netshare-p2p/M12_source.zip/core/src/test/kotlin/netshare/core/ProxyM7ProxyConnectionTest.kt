package netshare.core

import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

fun main() {
    val loop = InetAddress.getLoopbackAddress()
    val upstream = ServerSocket(0, 1, loop)
    val receiver = thread(isDaemon = true) {
        upstream.accept().use { socket ->
            socket.soTimeout = 4000
            val reader = socket.getInputStream().bufferedReader()
            check(reader.readLine() == "GET /resource HTTP/1.1")
            val headers = mutableListOf<String>()
            while (true) {
                val line = reader.readLine()
                if (line.isEmpty()) break
                headers += line
            }
            check(headers.none { it.startsWith("X-Sensitive:", ignoreCase = true) })
            check(headers.none { it.startsWith("Proxy-Connection:", ignoreCase = true) })
            check(headers.count { it.startsWith("Host:", ignoreCase = true) } == 1)
            socket.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nOK".toByteArray())
        }
    }
    try {
        ProxyCore(loop, 0, UpstreamConnector { host, port -> Socket(host, port) },
            { it.isLoopbackAddress }).use { proxy ->
            Socket(loop, proxy.start()).use { client ->
                client.soTimeout = 5000
                client.getOutputStream().write(("GET http://localhost:${upstream.localPort}/resource HTTP/1.1\r\n" +
                    "Proxy-Connection: X-Sensitive\r\nX-Sensitive: secret\r\n\r\n").toByteArray())
                val result = client.getInputStream().bufferedReader().readText()
                check(result.startsWith("HTTP/1.1 200 OK") && result.endsWith("OK"))
            }
        }
        receiver.join(3000)
        check(!receiver.isAlive) { "Upstream reader failed to finish" }
    } finally { upstream.close() }
    println("PASS M7: Proxy-Connection nominated header removed")
}
