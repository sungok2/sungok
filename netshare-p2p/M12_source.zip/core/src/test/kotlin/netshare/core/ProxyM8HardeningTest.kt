package netshare.core

import java.net.Inet4Address
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/** Standalone JVM regression tests; they do NOT verify cellular routing or Android Wi-Fi Direct. */
fun main() {
    val loop = InetAddress.getByName("127.0.0.1")
    val attempts = AtomicInteger()
    val target = ServerSocket(0, 2, loop)
    val targetThread = thread(name = "test-allowlist-remote") {
        target.use { listener ->
            listener.accept().use { s ->
                val input = s.getInputStream().bufferedReader()
                check(input.readLine().startsWith("GET /good HTTP/1.1"))
                while (!input.readLine().isNullOrEmpty()) { }
                s.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nOK".toByteArray())
            }
        }
    }
    val upstream = UpstreamConnector { host, port -> Socket(host, port) }
    ProxyCore(loop, 0, upstream, allowedClient = {
        if (attempts.incrementAndGet() == 1) throw IllegalStateException("network inspection failed")
        true
    }).use { proxy ->
        val proxyPort = proxy.start()
        Socket(loop, proxyPort).use { first ->
            first.soTimeout = 3000
            check(first.getInputStream().read() == -1) { "authorization error must deny first client" }
        }
        Socket(loop, proxyPort).use { second ->
            second.soTimeout = 4000
            val request = "GET http://127.0.0.1:${target.localPort}/good HTTP/1.1\r\nHost: localhost\r\n\r\n"
            second.getOutputStream().write(request.toByteArray())
            val result = second.getInputStream().bufferedReader().readText()
            check(result.startsWith("HTTP/1.1 200") && result.endsWith("OK")) {
                "acceptor must survive a failing client authorization lookup: $result"
            }
        }
    }
    targetThread.join(3000)
    check(!targetThread.isAlive)
    println("PASS M8: authorization lookup exception fails one peer closed without killing acceptor")

    val forbiddenConnector = UpstreamConnector { _, _ -> error("bad Host must be rejected before outbound connect") }
    val badRequests = listOf(
        "GET http://example.com/ HTTP/1.1\r\nHost: example.com\r\nHost: other.example\r\n\r\n",
        "POST http://example.com/ HTTP/1.1\r\nHost: \r\nContent-Length: 0\r\n\r\n",
        "GET http://example.com/ HTTP/1.1\r\nhOsT: example.com\r\nHOST: example.com\r\n\r\n",
    )
    ProxyCore(loop, 0, forbiddenConnector, { it.isLoopbackAddress }).use { proxy ->
        val port = proxy.start()
        for (request in badRequests) {
            Socket(loop, port).use { client ->
                client.soTimeout = 3000
                client.getOutputStream().write(request.toByteArray())
                val result = client.getInputStream().bufferedReader().readLine()
                check(result.startsWith("HTTP/1.1 400")) { "unsafe Host accepted: $result" }
            }
        }
    }
    println("PASS M8: three ambiguous/empty Host variants rejected before upstream")

    val invalidUpstream = UpstreamConnector { _, _ -> error("incomplete request must never connect") }
    ProxyCore(loop, 0, invalidUpstream, { it.isLoopbackAddress }, headerBudgetMillis = 560).use { proxy ->
        Socket(loop, proxy.start()).use { client ->
            client.soTimeout = 1800
            val sentAt = System.nanoTime()
            val output = client.getOutputStream()
            output.write('G'.code)
            output.flush()
            Thread.sleep(330)
            output.write('E'.code)
            output.flush()
            val firstLine = client.getInputStream().bufferedReader().readLine()
            val elapsedMs = (System.nanoTime() - sentAt) / 1_000_000
            check(firstLine.startsWith("HTTP/1.1 408")) { "expected 408, got $firstLine" }
            check(elapsedMs < 790) { "overall header deadline overshot: ${elapsedMs}ms" }
        }
    }
    println("PASS M8: incomplete header read observes remaining absolute deadline")

    fun addr(ip: String) = InetAddress.getByName(ip) as Inet4Address
    val allowed = listOf("192.168.49.2", "10.0.0.2", "172.16.0.6", "100.64.0.3", "8.8.8.8")
    val denied = listOf("0.0.0.0", "127.0.0.1", "169.254.5.6", "224.0.0.1", "239.255.255.250", "240.0.0.1", "255.255.255.255")
    allowed.forEach { check(ClientAddressPolicy.isUsableClient(addr(it))) { "should allow $it" } }
    denied.forEach { check(!ClientAddressPolicy.isUsableClient(addr(it))) { "should reject $it" } }
    println("PASS M8: ${allowed.size + denied.size} client IPv4 policy cases")
}
