package netshare.core

import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

fun main() {
    val local = InetAddress.getLoopbackAddress()
    // HTTP target
    val http = ServerSocket(0, 2, local)
    val httpThread = thread {
        http.accept().use { s ->
            val input = s.getInputStream().bufferedReader()
            check(input.readLine() == "GET /test?q=1 HTTP/1.1")
            while (input.readLine().isNotEmpty()) { }
            s.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nOK".toByteArray())
        }
    }
    // Only test connector (does not imply actual cellular routing)
    val connector = UpstreamConnector { host, port -> Socket(host, port) }
    ProxyCore(local, 0, connector, { it.isLoopbackAddress }).use { proxy ->
        val proxyPort = proxy.start()
        Socket(local, proxyPort).use { c ->
            c.soTimeout = 5000
            c.getOutputStream().write("GET http://localhost:${http.localPort}/test?q=1 HTTP/1.1\r\nHost: localhost\r\n\r\n".toByteArray())
            check(c.getInputStream().bufferedReader().readText().endsWith("OK"))
        }
    }
    httpThread.join(2000)
    http.close()
    println("PASS: HTTP absolute-form GET")

    val echo = ServerSocket(0, 2, local)
    val echoThread = thread {
        echo.accept().use { s ->
            val bytes = ByteArray(4)
            val input = s.getInputStream()
            var read = 0
            while (read < 4) read += input.read(bytes, read, 4 - read)
            s.getOutputStream().write(bytes)
        }
    }
    ProxyCore(local, 0, connector, { it.isLoopbackAddress }).use { proxy ->
        Socket(local, proxy.start()).use { c ->
            c.soTimeout = 5000
            val o = c.getOutputStream()
            o.write("CONNECT localhost:${echo.localPort} HTTP/1.1\r\nHost: localhost\r\n\r\n".toByteArray())
            val ins = c.getInputStream()
            val header = StringBuilder()
            while (!header.endsWith("\r\n\r\n")) {
                val ch = ins.read()
                check(ch != -1)
                header.append(ch.toChar())
            }
            check(header.toString().startsWith("HTTP/1.1 200"))
            o.write("PING".toByteArray())
            o.flush()
            val data = ByteArray(4)
            var offset = 0
            while (offset < 4) offset += ins.read(data, offset, 4 - offset)
            check(String(data) == "PING")
        }
    }
    echoThread.join(2000)
    echo.close()
    println("PASS: HTTPS CONNECT byte tunnel (TCP echo)")

    ProxyCore(local, 0, connector, { false }).use { proxy ->
        Socket(local, proxy.start()).use { c ->
            c.soTimeout = 3000
            check(c.getInputStream().read() == -1)
        }
    }
    println("PASS: Unauthorized client rejected")
}
