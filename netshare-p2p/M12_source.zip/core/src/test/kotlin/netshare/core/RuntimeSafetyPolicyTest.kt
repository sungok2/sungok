package netshare.core

fun main() {
    var count = 0
    for (role in P2pRole.entries) {
        for (interfaceUp in listOf(false, true)) {
            for (cellularStable in listOf(false, true)) {
                val actual = RuntimeSafetyPolicy.mayKeepRunning(role, interfaceUp, cellularStable)
                val expected = role == P2pRole.GROUP_CLIENT && interfaceUp && cellularStable
                check(actual == expected)
                println("PASS guard role=$role address=$interfaceUp cellular=$cellularStable => $actual")
                count++
            }
        }
    }
    println("TOTAL M6 SAFETY POLICY PASS: $count")
}
