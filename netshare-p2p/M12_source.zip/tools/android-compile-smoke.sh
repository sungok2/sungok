#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build
# STUB compilation catches syntax and some Kotlin type errors ONLY.
# This does not use Android SDK and is NOT evidence of a buildable APK.
kotlinc tools/android-compile-stubs/*.kt \
 core/src/main/kotlin/netshare/core/ProxyCore.kt \
 core/src/main/kotlin/netshare/core/P2pRolePolicy.kt \
 core/src/main/kotlin/netshare/core/ClientAddressPolicy.kt \
 core/src/main/kotlin/netshare/core/RuntimeSafetyPolicy.kt \
 core/src/main/kotlin/netshare/core/EgressAddressPolicy.kt \
 android-adapter/src/main/java/netshare/android/*.kt \
 android-app/src/main/java/netshare/app/*.kt \
 -d build/android-smoke.jar
python3 - <<'PY'
import xml.etree.ElementTree as ET
ET.parse('android-app/src/main/AndroidManifest.xml')
print('PASS: AndroidManifest.xml parsed as XML')
PY
printf '%s\n' 'PASS: Kotlin Android sources compiled against local synthetic stubs (NOT SDK/Gradle)'
