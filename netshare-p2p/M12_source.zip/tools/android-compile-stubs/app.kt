package android.app
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.IBinder
import android.view.View
open class Activity : Context() {
    open fun onCreate(savedInstanceState: Bundle?) {}
    open fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {}
    fun setContentView(v: View) {}
    fun requestPermissions(permissions: Array<String>, requestCode: Int) {}
    fun startForegroundService(intent: Intent) {}
    fun startActivity(intent: Intent) {}
    fun stopService(intent: Intent): Boolean = false
}
open class Service : Context() {
    open fun onCreate() {}
    open fun onBind(intent: Intent?): IBinder? = null
    open fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_NOT_STICKY
    open fun onDestroy() {}
    fun startForeground(id: Int, n: Notification) {}
    fun stopSelf() {}
    fun stopSelf(startId: Int) {}
    companion object { const val START_NOT_STICKY = 2 }
}
class Notification {
    class Builder(c: Context, channelId: String) {
        fun setSmallIcon(id: Int): Builder = this
        fun setContentTitle(s: CharSequence): Builder = this
        fun setContentText(s: CharSequence): Builder = this
        fun setOngoing(b: Boolean): Builder = this
        fun addAction(a: Action): Builder = this
        fun build() = Notification()
    }
    class Action {
        class Builder(icon: Any?, title: CharSequence, intent: PendingIntent) {
            fun build() = Action()
        }
    }
}
class NotificationChannel(id: String, name: CharSequence, importance: Int)
class NotificationManager {
    fun createNotificationChannel(c: NotificationChannel) {}
    fun notify(id: Int, n: Notification) {}
    companion object { const val IMPORTANCE_LOW = 2 }
}
class PendingIntent { companion object {
    const val FLAG_UPDATE_CURRENT = 1; const val FLAG_IMMUTABLE = 2
    fun getService(c: Context, code: Int, intent: Intent, flags: Int) = PendingIntent()
} }
