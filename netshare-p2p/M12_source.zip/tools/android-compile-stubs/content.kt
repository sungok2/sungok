package android.content
import android.content.pm.PackageManager
import android.os.Looper
open class Context {
    fun checkSelfPermission(permission: String) = 0
    val packageManager = PackageManager()
    val mainLooper = Looper()
    fun <T> getSystemService(clazz: Class<T>): T = throw UnsupportedOperationException("stub")
    fun getSystemService(name: String): Any? = null
    fun getSharedPreferences(name: String, mode: Int): SharedPreferences = SharedPreferences()
    companion object { const val WIFI_P2P_SERVICE = "wifip2p"; const val NOTIFICATION_SERVICE = "notification"; const val CLIPBOARD_SERVICE = "clipboard"; const val MODE_PRIVATE = 0 }
}
class Intent {
    constructor(context: Context, clazz: Class<*>)
    constructor(action: String)
    val action: String? = null
    fun setAction(s: String): Intent = this
    fun putExtra(key: String, value: String): Intent = this
    fun putExtra(key: String, value: Boolean): Intent = this
    fun getBooleanExtra(key: String, default: Boolean): Boolean = default
    fun getStringExtra(key: String): String? = null
}

class SharedPreferences {
    fun getString(key: String, default: String?): String? = default
    fun edit(): Editor = Editor()
    class Editor {
        fun putString(key: String, value: String): Editor = this
        fun apply() {}
    }
}

class ClipData { companion object { fun newPlainText(label: CharSequence, text: CharSequence): ClipData = ClipData() } }
class ClipboardManager { fun setPrimaryClip(clip: ClipData) {} }
