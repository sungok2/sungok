package android
object Manifest { object permission { const val NEARBY_WIFI_DEVICES = "android.permission.NEARBY_WIFI_DEVICES"; const val CHANGE_WIFI_STATE = "android.permission.CHANGE_WIFI_STATE"; const val CHANGE_NETWORK_STATE = "android.permission.CHANGE_NETWORK_STATE" } }
object R { object drawable { const val stat_sys_upload = 1 } }
