package android.net
import java.net.InetAddress
import javax.net.SocketFactory
class Network {
    fun getAllByName(host: String): Array<InetAddress> = arrayOf()
    val socketFactory: SocketFactory get() = SocketFactory.getDefault()
}
class NetworkCapabilities {
    fun hasTransport(v: Int) = false
    fun hasCapability(v: Int) = false
    companion object { const val TRANSPORT_CELLULAR = 0; const val NET_CAPABILITY_INTERNET = 1; const val NET_CAPABILITY_VALIDATED = 2 }
}
class ConnectivityManager {
    val allNetworks: Array<Network> = arrayOf()
    fun getNetworkCapabilities(n: Network): NetworkCapabilities? = null
    fun getLinkProperties(n: Network): LinkProperties? = null
}

class IpPrefix {
    val address: InetAddress get() = InetAddress.getLoopbackAddress()
    val prefixLength: Int get() = 96
}
class LinkProperties { val nat64Prefix: IpPrefix? = null }
