package android.os
class Bundle
class Looper
interface IBinder
object Build {
    const val MODEL = "stub"
    object VERSION { const val SDK_INT = 33 }
}

class Handler(looper: Looper) {
    fun postDelayed(action: Runnable, millis: Long): Boolean = true
    fun removeCallbacks(action: Runnable) {}
    fun removeCallbacksAndMessages(token: Any?) {}
}
