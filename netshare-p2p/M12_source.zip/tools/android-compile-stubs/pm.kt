package android.content.pm
class PackageManager {
    fun hasSystemFeature(s: String): Boolean = false
    companion object { const val PERMISSION_GRANTED = 0; const val FEATURE_WIFI_DIRECT = "android.hardware.wifi.direct" }
}
