package android.provider
object Settings { const val ACTION_WIFI_SETTINGS = "android.settings.WIFI_SETTINGS" }
