package android.view
import android.content.Context
open class View(val context: Context)
