package android.widget
import android.content.Context
import android.view.View
open class TextView(c: Context): View(c) {
    var text: CharSequence = ""
    var textSize: Float = 12f
    fun setTextIsSelectable(b: Boolean) {}
    fun append(t: CharSequence) {}
}
class EditText(c: Context): TextView(c) {
    var hint: CharSequence = ""
    fun setSingleLine(b: Boolean) {}
    fun setText(s: String) { text = s }
}
class CheckBox(c: Context): TextView(c) { var isChecked: Boolean = false }
class Button(c: Context): TextView(c) { fun setOnClickListener(callback: (View) -> Unit) {} }
open class LinearLayout(c: Context): View(c) {
    var orientation: Int = 0
    fun setPadding(a: Int, b: Int, c: Int, d: Int) {}
    fun addView(v: View) {}
    companion object { const val VERTICAL = 1 }
}
class ScrollView(c: Context): View(c) { fun addView(v: View) {} }
