package android.net.wifi.p2p
import android.content.Context
import android.os.Looper
class WifiP2pManager {
    companion object { const val WIFI_P2P_STATE_ENABLED = 2 }
    interface ActionListener { fun onSuccess(); fun onFailure(reason: Int) }
    class Device { val deviceName: String = ""; val status: Int = 0 }
    class DeviceList { val deviceList: Collection<Device> = emptyList() }
    fun requestP2pState(ch: Channel, cb: (Int) -> Unit) {}
    fun discoverPeers(ch: Channel, cb: ActionListener) {}
    fun requestPeers(ch: Channel, cb: (DeviceList?) -> Unit) {}
    class Channel
    class Group { val isGroupOwner = false; val clientList: List<String> = emptyList(); fun getInterface() = "" }
    fun initialize(c: Context, l: Looper, callback: Any?): Channel? = null
    class Info { val groupFormed = false; val isGroupOwner = false; val groupOwnerAddress: java.net.InetAddress? = null }
    fun requestGroupInfo(ch: Channel, callback: (Group?) -> Unit) {}
    fun requestConnectionInfo(ch: Channel, callback: (Info?) -> Unit) {}
}
