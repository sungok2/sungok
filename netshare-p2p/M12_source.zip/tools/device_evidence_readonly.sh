#!/usr/bin/env bash
# Passive evidence snapshot only; does not create/change P2P groups, Wi-Fi or routes.
# CAUTION: dumpsys data can include SSIDs, MAC/IP addresses and internal network state.
# Do not upload raw output without redaction and authorization.
set -euo pipefail
if ! command -v adb >/dev/null 2>&1; then
  echo 'ADB is required. Run on a PC with Android platform-tools.' >&2
  exit 2
fi
number=$(adb devices | awk 'NR>1 && $2 == "device" {count++} END {print count+0}')
if [ "$number" -ne 1 ]; then
  echo 'Exactly one authorized ADB device must be connected.' >&2
  exit 2
fi
out="${1:-device-evidence-$(date +%Y%m%d-%H%M%S)}"
mkdir -p "$out"
{
  date -u '+Capture UTC: %Y-%m-%dT%H:%M:%SZ'
  adb shell getprop ro.product.model
  adb shell getprop ro.build.version.release
  adb shell getprop ro.build.version.sdk
  adb shell getprop ro.build.fingerprint
} > "$out/device.txt" 2>&1
# Failure/permission denial is recorded, never interpreted as an empty state.
adb shell ip -o addr show > "$out/interface-addresses.txt" 2>&1 || true
adb shell dumpsys wifi p2p > "$out/wifi-p2p-dumpsys.txt" 2>&1 || true
adb shell dumpsys tethering > "$out/tethering-dumpsys.txt" 2>&1 || true
adb shell dumpsys connectivity > "$out/connectivity-dumpsys.txt" 2>&1 || true
{
  echo 'RAW DEVICE SNAPSHOT — SENSITIVE: review before sharing.'
  echo 'This tool NEVER enables hotspot/P2P/tethering and NEVER proves absence of historical or transient invocations.'
  echo 'Collect separately at idle and during an already-authorized, externally compliant connection.'
  echo 'Permission denials, missing services and incomplete dumpsys invalidate conclusions.'
} > "$out/READ_ME_FIRST.txt"
( cd "$out" && sha256sum *.txt > SHA256SUMS.txt )
printf 'Read-only snapshots written to %s (sensitive). No P2P/Tethering commands were issued.\n' "$out"
