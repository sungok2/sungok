#!/usr/bin/env bash
# Device identification only. No Wi-Fi state changes; no discovery, group creation or tethering calls.
set -euo pipefail
if ! command -v adb >/dev/null 2>&1; then
  echo 'ADB not installed. Run this on a computer with Android platform-tools.' >&2
  exit 2
fi
if [ "$(adb devices | awk 'NR>1 && $2 == "device" {count++} END {print count+0}')" -ne 1 ]; then
  echo 'Exactly one authorized Android device must be connected.' >&2
  exit 2
fi
printf 'Model: ' ; adb shell getprop ro.product.model | tr -d '\r'
printf 'Android release: ' ; adb shell getprop ro.build.version.release | tr -d '\r'
printf 'SDK: ' ; adb shell getprop ro.build.version.sdk | tr -d '\r'
printf 'Build fingerprint: ' ; adb shell getprop ro.build.fingerprint | tr -d '\r'
printf 'Wi-Fi Direct declared feature: ' ; adb shell pm list features | grep -m1 'android.hardware.wifi.direct' || true
printf '%s\n' 'This passive probe CANNOT prove that Android internal Tethering is absent.'
