#!/usr/bin/env python3
"""Heuristic static audit, not proof of vendor/Android internal behavior."""
from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
dirs = [root/'android-app/src/main', root/'android-adapter/src/main', root/'core/src/main']
files = sorted(p for d in dirs for p in d.rglob('*') if p.suffix in ('.kt','.java','.xml'))
checks = {
  'Tethering': r'\b(?:TetheringManager|TETHERING_WIFI_P2P|TETHER_PRIVILEGED|startTethering|stopTethering)\b',
  'P2P group/connection mutation': r'\b(?:createGroup|removeGroup|startListening)\s*\(|\b(?:p2pManager|wifiP2pManager|manager)\.connect\s*\(',
  'SoftAP': r'\b(?:startLocalOnlyHotspot|setWifiApEnabled|SoftApConfiguration|startSoftAp)\b',
  'privileged permission': r'android\.permission\.(?:NETWORK_STACK|TETHER_PRIVILEGED)',
}
fail = 0
for path in files:
    data = path.read_text(encoding='utf8')
    # Scan literal source as well as comments to avoid missing suspicious API tokens.
    for kind, pattern in checks.items():
        if re.search(pattern, data):
            print(f'FAIL {path.relative_to(root)}: {kind}')
            fail += 1
print(f'Scanned {len(files)} source and manifest files; forbidden API findings: {fail}')
print('WARNING: source scan cannot prove internal Android Tethering absence')
sys.exit(1 if fail else 0)
