#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p build test-results
python3 tools/policy_audit.py
if command -v kotlinc >/dev/null 2>&1; then
  KOTLINC=kotlinc
else
  echo 'Kotlin compiler required' >&2; exit 3
fi
"$KOTLINC" core/src/main/kotlin/netshare/core/ProxyCore.kt \
 core/src/main/kotlin/netshare/core/P2pRolePolicy.kt \
 core/src/main/kotlin/netshare/core/ClientAddressPolicy.kt \
 core/src/main/kotlin/netshare/core/RuntimeSafetyPolicy.kt \
 core/src/main/kotlin/netshare/core/EgressAddressPolicy.kt \
 android-app/src/main/java/netshare/app/P2pNetworkInspector.kt \
 core/src/test/kotlin/netshare/core/ProxySmokeTest.kt \
 core/src/test/kotlin/netshare/core/ProxyExtendedTest.kt \
 core/src/test/kotlin/netshare/core/ProxyLifecycleTest.kt \
 core/src/test/kotlin/netshare/core/ProxyM5Test.kt \
 core/src/test/kotlin/netshare/core/P2pRolePolicyTest.kt \
 core/src/test/kotlin/netshare/core/EgressAddressPolicyTest.kt \
 core/src/test/kotlin/netshare/core/ProxyM6IntegrityTest.kt \
 core/src/test/kotlin/netshare/core/RuntimeSafetyPolicyTest.kt \
 core/src/test/kotlin/netshare/core/Nat64EgressTest.kt \
 core/src/test/kotlin/netshare/core/HeaderDeadlineTest.kt \
 core/src/test/kotlin/netshare/core/ProxyM7FramingTest.kt \
 core/src/test/kotlin/netshare/core/ProxyM7ProxyConnectionTest.kt \
 core/src/test/kotlin/netshare/core/ProxyM8HardeningTest.kt \
 core/src/test/kotlin/netshare/app/P2pInspectorTest.kt \
 -include-runtime -d build/tests.jar
java -cp build/tests.jar netshare.core.ProxySmokeTestKt
java -cp build/tests.jar netshare.core.ProxyExtendedTestKt
java -cp build/tests.jar netshare.core.ProxyLifecycleTestKt
java -cp build/tests.jar netshare.app.P2pInspectorTestKt

java -cp build/tests.jar netshare.core.ProxyM5TestKt
java -cp build/tests.jar netshare.core.P2pRolePolicyTestKt
java -cp build/tests.jar netshare.core.EgressAddressPolicyTestKt

java -cp build/tests.jar netshare.core.ProxyM6IntegrityTestKt
java -cp build/tests.jar netshare.core.RuntimeSafetyPolicyTestKt
java -cp build/tests.jar netshare.core.Nat64EgressTestKt
java -cp build/tests.jar netshare.core.HeaderDeadlineTestKt

java -cp build/tests.jar netshare.core.ProxyM7FramingTestKt
java -cp build/tests.jar netshare.core.ProxyM7ProxyConnectionTestKt

java -cp build/tests.jar netshare.core.ProxyM8HardeningTestKt
