#!/usr/bin/env bash
# Fully local checks; NO Android SDK or physical device involved.
set -euo pipefail
cd "$(dirname "$0")/.."
bash tools/verify.sh
bash tools/android-compile-smoke.sh
printf '%s\n' 'Local checks done. Android APK, hardware, and Tethering-absence are NOT verified.'

python3 tools/verify_m11.py
