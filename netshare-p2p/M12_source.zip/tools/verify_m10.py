#!/usr/bin/env python3
"""Static gates only, not proof of runtime Android Tethering absence."""
from pathlib import Path
from xml.etree import ElementTree as ET
root = Path(__file__).resolve().parent.parent
app = root / 'android-app/src/main/java/netshare/app'
main = (app / 'ProbeActivity.kt').read_text()
all_src = '\n'.join(p.read_text() for p in root.glob('**/src/main/**/*.kt'))
for forbidden in ('createGroup(', 'manager.connect(channel', 'startTethering(', 'TetheringManager',
                  'startLocalOnlyHotspot(', 'setWifiApEnabled('):
    assert forbidden not in all_src, f'Forbidden direct call: {forbidden}'
assert 'requestConnectionInfo(channel)' in main
assert 'requestGroupInfo(channel)' in main
assert 'fillFromVerifiedClientRole' in main
assert 'Role.GROUP_CLIENT' in main
manifest = ET.parse(root / 'android-app/src/main/AndroidManifest.xml').getroot()
ns = '{http://schemas.android.com/apk/res/android}'
permissions = {p.attrib.get(ns+'name') for p in manifest.findall('uses-permission')}
for required in ('android.permission.NEARBY_WIFI_DEVICES', 'android.permission.INTERNET',
                 'android.permission.CHANGE_WIFI_STATE', 'android.permission.ACCESS_WIFI_STATE'):
    assert required in permissions, required
print('PASS M10 read-only P2P UI, manifest, no prohibited direct API patterns')
