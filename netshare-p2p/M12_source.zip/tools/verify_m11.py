#!/usr/bin/env python3
"""M11 build/source contract checks only; not proof of vendor-service behavior."""
from pathlib import Path
from xml.etree import ElementTree as ET
root=Path(__file__).resolve().parent.parent
src=(root/'android-app/src/main/java/netshare/app/ProbeActivity.kt').read_text()
all_src='\n'.join(p.read_text() for p in root.glob('**/src/main/**/*.kt'))
assert 'manager.requestP2pState(channel)' in src
assert 'manager.discoverPeers(channel' in src
assert 'manager.requestPeers(channel)' in src
assert 'manager.requestConnectionInfo(channel)' in src
assert 'manager.requestGroupInfo(channel)' in src
assert 'startProxyIfConfirmed' in src
assert 'Role.GROUP_CLIENT' in src
for forbidden in ('createGroup(', 'manager.connect(', 'manager.removeGroup(', 'startTethering(',
                  'TetheringManager', 'startLocalOnlyHotspot(', 'setWifiApEnabled('):
    assert forbidden not in all_src, forbidden
ns='{http://schemas.android.com/apk/res/android}'
manifest=ET.parse(root/'android-app/src/main/AndroidManifest.xml').getroot()
permissions={x.attrib.get(ns+'name') for x in manifest.findall('uses-permission')}
for req in ('android.permission.NEARBY_WIFI_DEVICES','android.permission.INTERNET',
            'android.permission.ACCESS_WIFI_STATE','android.permission.CHANGE_WIFI_STATE'):
    assert req in permissions, req
print('PASS M11: user-initiated discovery, passive P2P readback, no direct group/connection/tethering mutation')
print('WARNING: these checks cannot prove Samsung firmware or remote-device compliance')
