package netshare.android

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities

/** Do not fall back silently to Wi-Fi when cellular is unavailable. */
object CellularSelector {
    fun select(context: Context): Network? {
        val cm = context.getSystemService(ConnectivityManager::class.java)
        return cm.allNetworks.firstOrNull { n ->
            val cap = cm.getNetworkCapabilities(n)
            cap?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) == true &&
                cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        }
    }
}
