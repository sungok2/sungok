package netshare.android

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import netshare.core.UpstreamConnector
import netshare.core.EgressAddressPolicy
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Fail-closed: re-check cellular capabilities before every upstream connection.
 * A selected Network may disappear between the capability check and connect;
 * in that case Network-bound socket operations throw instead of falling back.
 * This has not been verified on the target Samsung device.
 */
class CellularUpstreamConnector(context: Context, private val network: Network) : UpstreamConnector {
    private val cm = context.getSystemService(ConnectivityManager::class.java)

    override fun connect(host: String, port: Int): Socket {
        require(port in 1..65535)
        val capabilities = cm.getNetworkCapabilities(network)
        if (capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) != true ||
            !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
            !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) {
            throw IOException("Selected cellular Network unavailable or unvalidated; no Wi-Fi fallback")
        }
        val nat64 = cm.getLinkProperties(network)?.nat64Prefix
        var error: Exception? = null
        for (address in network.getAllByName(host)) {
            // Do not let a permitted client tunnel to loopback/private carrier services.
            // Other addresses use a socket explicitly bound to this cellular Network.
            if (!EgressAddressPolicy.isAllowed(address,
                    nat64?.address, nat64?.prefixLength ?: -1)) continue
            val socket = network.socketFactory.createSocket()
            try {
                socket.connect(InetSocketAddress(address, port), 10_000)
                return socket
            } catch (e: Exception) {
                error = e
                try { socket.close() } catch (_: IOException) { }
            }
        }
        throw IOException("All selected cellular addresses failed", error)
    }
}
