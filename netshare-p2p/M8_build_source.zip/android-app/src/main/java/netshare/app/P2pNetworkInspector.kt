package netshare.app

import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface

/** Interface enumeration only: never creates/configures P2P or network routes. */
object P2pNetworkInspector {
    data class InterfaceAddress(val interfaceName: String, val address: Inet4Address)

    fun activeP2pIPv4(): List<InterfaceAddress> = try {
        NetworkInterface.getNetworkInterfaces()?.toList().orEmpty().filter { nic ->
            nic.isUp && (nic.name.startsWith("p2p", ignoreCase = true) ||
                nic.name.contains("-p2p", ignoreCase = true))
        }.flatMap { nic ->
            nic.inetAddresses.toList().filterIsInstance<Inet4Address>()
                .filter { !it.isAnyLocalAddress && !it.isLoopbackAddress &&
                    !it.isLinkLocalAddress && !it.isMulticastAddress }
                .map { InterfaceAddress(nic.name, it) }
        }
    } catch (_: Exception) { emptyList() }

    /** Numeric dotted IPv4 only; never resolves an untrusted hostname. */
    fun parseIPv4(value: String): Inet4Address? {
        val fields = value.split('.')
        if (fields.size != 4 || fields.any { it.isEmpty() || it.length > 3 ||
                !it.all(Char::isDigit) || (it.length > 1 && it.startsWith('0')) }) return null
        val nums = fields.map { it.toIntOrNull() ?: return null }
        if (nums.any { it !in 0..255 }) return null
        return InetAddress.getByAddress(nums.map { it.toByte() }.toByteArray()) as Inet4Address
    }
}
