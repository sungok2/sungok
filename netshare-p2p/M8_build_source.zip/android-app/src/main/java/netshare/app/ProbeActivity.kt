package netshare.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import netshare.android.CellularSelector

/** Only existing group info and interfaces can be queried. No P2P creation or network change. */
class ProbeActivity : Activity() {
    private lateinit var stateText: TextView
    private lateinit var localIpText: EditText
    private lateinit var clientIpText: EditText
    private lateinit var attested: CheckBox
    private val nearbyRequestCode = 6010

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 20, 28, 20)
        }
        fun message(s: String) = root.addView(TextView(this).apply { text = s; textSize = 15f })
        message("NetShare P2P · 조건부 프록시 M8")
        message("이 앱은 Wi-Fi Direct 그룹을 만들거나 테더링을 실행하지 않습니다. 호스트가 Group Owner이면 프록시 실행을 거부합니다. Group Client라도 전체 링크의 준수 여부는 자동 증명할 수 없습니다.")
        root.addView(Button(this).apply {
            text = "기존 P2P 인터페이스 / 셀룰러 상태 조회"
            setOnClickListener { inspectWithPermission() }
        })
        stateText = TextView(this).apply {
            text = "조회 전: 적합한 기존 P2P 링크는 확인되지 않았습니다."; textSize = 13f
            setTextIsSelectable(true)
        }
        root.addView(stateText)
        message("현재 P2P 인터페이스의 IPv4 주소 (예: 192.168.49.1)")
        localIpText = EditText(this).apply { hint = "직접 확인한 P2P IPv4"; setSingleLine(true) }
        root.addView(localIpText)
        message("허용할 클라이언트의 IPv4 주소 (정확히 1개)")
        clientIpText = EditText(this).apply { hint = "클라이언트 IPv4"; setSingleLine(true) }
        root.addView(clientIpText)
        attested = CheckBox(this).apply {
            text = "별도 장치/펌웨어 검증으로 해당 기존 링크에서 Android Tethering/SoftAP/Hotspot이 전혀 호출되지 않음을 확인함 (앱 자체는 검증 불가)"
            isChecked = false
        }
        root.addView(attested)
        root.addView(Button(this).apply {
            text = "조건부 프록시 실행 (포트 8282)"
            setOnClickListener { startProxyIfConfirmed() }
        })
        root.addView(Button(this).apply {
            text = "최근 실행 상태 / 거부 사유 확인"
            setOnClickListener { stateText.append("\n" + ServiceStatus.read(this@ProbeActivity)) }
        })
        root.addView(Button(this).apply {
            text = "프록시 종료"
            setOnClickListener {
                stopService(Intent(this@ProbeActivity, ProxyService::class.java))
                stateText.append("\n프록시 종료를 요청했습니다.")
            }
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun startProxyIfConfirmed() {
        // Group-info observation requires Nearby Wi-Fi Devices runtime permission.
        // Request explicitly rather than allowing the service to fail with a
        // SecurityException after the user has pressed Start.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            stateText.append("\n시작 거절: 주변 Wi-Fi 기기 권한이 없습니다. 권한 승인 후 다시 실행하세요.")
            requestPermissions(arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES), nearbyRequestCode)
            return
        }
        val local = P2pNetworkInspector.parseIPv4(localIpText.text.toString())
        val client = P2pNetworkInspector.parseIPv4(clientIpText.text.toString())
        if (!attested.isChecked || local == null || client == null ||
            P2pNetworkInspector.activeP2pIPv4().none { it.address == local }) {
            stateText.append("\n시작 거절: 독립적 준수 검증 확인, 올바른 두 주소, 활성 P2P 인터페이스가 필요합니다.")
            return
        }
        if (CellularSelector.select(this) == null) {
            stateText.append("\n시작 거절: 검증된 셀룰러 인터넷 연결이 없습니다.")
            return
        }
        val service = Intent(this, ProxyService::class.java)
            .setAction(ProxyService.ACTION_START)
            .putExtra(ProxyService.EXTRA_LISTEN_IP, local.hostAddress)
            .putExtra(ProxyService.EXTRA_CLIENT_IP, client.hostAddress)
            .putExtra(ProxyService.EXTRA_OPERATOR_ATTESTED, true)
        try {
            startForegroundService(service)
            stateText.append("\n프록시 시작 요청 전송. 실행 성공 여부는 알림을 확인하세요.")
        } catch (e: Exception) {
            stateText.append("\n시작 요청 실패: ${e.javaClass.simpleName}")
        }
    }

    private fun inspectWithPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.NEARBY_WIFI_DEVICES) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.NEARBY_WIFI_DEVICES), nearbyRequestCode)
            return
        }
        inspectReadOnly()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>,
                                            grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == nearbyRequestCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            inspectReadOnly()
        } else if (requestCode == nearbyRequestCode) {
            stateText.text = "NEARBY_WIFI_DEVICES 권한 거부: 그룹 정보 조회 불가"
        }
    }

    private fun inspectReadOnly() {
        val lines = mutableListOf<String>()
        lines += "기기=${Build.MODEL}; API=${Build.VERSION.SDK_INT}"
        lines += "Wi-Fi Direct 지원=${packageManager.hasSystemFeature(PackageManager.FEATURE_WIFI_DIRECT)}"
        lines += "검증된 셀룰러 Network=${CellularSelector.select(this) != null}"
        val p2ps = P2pNetworkInspector.activeP2pIPv4()
        if (p2ps.isEmpty()) {
            lines.add("활성 P2P IPv4: 없음")
        } else {
            lines.addAll(p2ps.map { "${it.interfaceName}: ${it.address.hostAddress}" })
        }
        lines += "P2P 그룹 존재는 Tethering 미사용의 증거가 아닙니다."
        stateText.text = lines.joinToString("\n")
        val manager = getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
        if (manager == null) { stateText.append("\nWifiP2pManager 없음"); return }
        try {
            val channel = manager.initialize(this, mainLooper, null)
            if (channel == null) { stateText.append("\nP2P 채널 없음"); return }
            manager.requestGroupInfo(channel) { group ->
                if (group == null) stateText.append("\n관찰된 기존 그룹 없음")
                else {
                    stateText.append("\n관찰된 기존 그룹: GO=${group.isGroupOwner}, interface=${group.getInterface()}, clients=${group.clientList.size}")
                    if (group.isGroupOwner) stateText.append("\n차단: Galaxy가 Group Owner입니다. AOSP GO 경로에서 Android Tethering이 사용될 수 있으므로 실행할 수 없습니다.")
                    else stateText.append("\nGroup Client 역할 확인. 그러나 외부 GO와 링크의 규정 준수는 별도 검증이 필요합니다.")
                }
            }
        } catch (e: Exception) { stateText.append("\nP2P 그룹 조회 실패: ${e.javaClass.simpleName}") }
    }
}
