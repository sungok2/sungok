package netshare.app

import android.content.Context

/** Small local status string; no client traffic, passwords or URLs are persisted. */
object ServiceStatus {
    private const val PREFS = "netshare_status"
    private const val KEY = "last_state"
    fun write(context: Context, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, value).apply()
    }
    fun read(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "실행 기록 없음")
            ?: "실행 기록 없음"
}
