package netshare.core

import java.net.Inet4Address

/** A manually configured proxy peer must be a usable unicast IPv4 address. */
object ClientAddressPolicy {
    fun isUsableClient(address: Inet4Address): Boolean {
        val b = address.address.map { it.toInt() and 0xff }
        val first = b[0]
        return first in 1..223 && first != 127 &&
            !(first == 169 && b[1] == 254) &&
            !address.isAnyLocalAddress && !address.isLoopbackAddress &&
            !address.isLinkLocalAddress && !address.isMulticastAddress &&
            b != listOf(255, 255, 255, 255)
    }
}
