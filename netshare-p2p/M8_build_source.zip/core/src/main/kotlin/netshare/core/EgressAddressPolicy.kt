package netshare.core

import java.net.Inet4Address
import java.net.Inet6Address
import java.net.InetAddress

/**
 * Reject obvious local, multicast and non-public destinations.
 * This is defense in depth for an allowed client, not a complete IANA registry
 * classifier and not a substitute for Android's cellular Network binding.
 */
object EgressAddressPolicy {
    /**
     * Extra NAT64 controls prevent an IPv4 private address from being disguised as a
     * public-looking synthesized IPv6 address. Android may use a network-specific /96
     * prefix; the well-known 64:ff9b::/96 prefix is handled even when not advertised.
     */
    fun isAllowed(address: InetAddress, nat64Prefix: InetAddress? = null,
                  nat64PrefixLength: Int = -1): Boolean {
        if (address.isAnyLocalAddress || address.isLoopbackAddress || address.isLinkLocalAddress ||
            address.isMulticastAddress || address.isSiteLocalAddress) return false
        val bytes = address.address.map { it.toInt() and 0xff }
        return when (address) {
            is Inet4Address -> {
                val a = bytes[0]
                val b = bytes[1]
                val c = bytes[2]
                when {
                    a == 0 || a >= 224 -> false
                    a == 100 && b in 64..127 -> false   // CGNAT shared space, RFC 6598
                    a == 169 && b == 254 -> false
                    a == 192 && b == 0 && c == 0 -> false // IETF protocol assignments
                    a == 192 && b == 0 && c == 2 -> false // documentation
                    a == 198 && b in 18..19 -> false // benchmarking
                    a == 198 && b == 51 && c == 100 -> false // documentation
                    a == 203 && b == 0 && c == 113 -> false // documentation
                    else -> true
                }
            }
            is Inet6Address -> {
                when {
                    bytes[0] and 0xfe == 0xfc -> false  // Unique-local fc00::/7
                    bytes[0] == 0x20 && bytes[1] == 0x01 && bytes[2] == 0x0d && bytes[3] == 0xb8 -> false // documentation
                    bytes[0] == 0x20 && bytes[1] == 0x02 -> false // 6to4 tunnel, fail closed
                    bytes[0] == 0x20 && bytes[1] == 0x01 && bytes[2] == 0 && bytes[3] == 0 -> false // Teredo tunnel
                    isNat64WellKnown(bytes) -> isAllowed(v4Embedded(bytes))
                    nat64Prefix != null && nat64PrefixLength == 96 &&
                        nat64Prefix.address.size == 16 &&
                        bytes.take(12) == nat64Prefix.address.take(12).map { it.toInt() and 0xff } ->
                        isAllowed(v4Embedded(bytes))
                    else -> true
                }
            }
            else -> false
        }
    }

    private fun v4Embedded(bytes: List<Int>): InetAddress =
        InetAddress.getByAddress(bytes.subList(12, 16).map { it.toByte() }.toByteArray())

    private fun isNat64WellKnown(bytes: List<Int>): Boolean =
        bytes.subList(0, 4) == listOf(0, 100, 255, 155) &&
            bytes.subList(4, 12).all { it == 0 }
}
