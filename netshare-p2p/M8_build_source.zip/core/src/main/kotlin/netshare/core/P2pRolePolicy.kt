package netshare.core

/**
 * Conservative policy, not proof that a group-client link is tethering-free.
 * It rejects the Android handset as Group Owner because the studied AOSP GO
 * path requests Android Tethering for IP serving. A remote non-Android GO can
 * theoretically be compatible, but requires independent firmware/link evidence.
 */
enum class P2pRole { ABSENT, GROUP_OWNER, GROUP_CLIENT }

object P2pRolePolicy {
    fun canStart(role: P2pRole, linkIndependentlyVerified: Boolean): Boolean =
        role == P2pRole.GROUP_CLIENT && linkIndependentlyVerified
}
