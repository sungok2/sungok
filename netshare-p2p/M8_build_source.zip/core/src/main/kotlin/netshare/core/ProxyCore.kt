package netshare.core

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit

/** Only the injected connector can create upstream sockets. Android implementation binds to CELLULAR. */
fun interface UpstreamConnector {
    @Throws(IOException::class)
    fun connect(host: String, port: Int): Socket
}

/** Laboratory HTTP/1.1 forward proxy, not a full RFC-compliant or production hardened proxy. */
class ProxyCore(
    private val listenAddress: InetAddress,
    private val port: Int,
    private val upstream: UpstreamConnector,
    private val allowedClient: (InetAddress) -> Boolean = { false },
    private val maxClients: Int = 16,
    private val headerBudgetMillis: Long = 12_000,
) : Closeable {
    init {
        require(!listenAddress.isAnyLocalAddress && !listenAddress.isMulticastAddress) {
            "Explicit unicast bind address required; wildcard/multicast is forbidden"
        }
        require(port in 0..65535)
        require(maxClients in 1..128)
        require(headerBudgetMillis in 100..120_000)
    }

    private val clients = ConcurrentHashMap.newKeySet<Socket>()
    private val remoteSockets = ConcurrentHashMap.newKeySet<Socket>()
    private val permits = Semaphore(maxClients)
    private val workers = Executors.newCachedThreadPool { r ->
        Thread(r, "netshare-proxy-worker").apply { isDaemon = true }
    }
    @Volatile private var server: ServerSocket? = null
    @Volatile private var running = false
    @Volatile private var closed = false
    private var acceptor: Thread? = null

    @Synchronized fun start(): Int {
        check(!running) { "Already running" }
        check(!closed) { "ProxyCore cannot restart after close()" }
        val listener = ServerSocket()
        listener.reuseAddress = true
        listener.bind(InetSocketAddress(listenAddress, port), maxClients)
        server = listener
        running = true
        acceptor = Thread({ acceptLoop(listener) }, "netshare-proxy-accept").apply {
            isDaemon = true
            start()
        }
        return listener.localPort
    }

    private fun acceptLoop(listener: ServerSocket) {
        while (running) {
            val client = try { listener.accept() } catch (_: IOException) { break }
            // A failure in an OS/interface-backed authorization lookup must fail
            // this single connection CLOSED, not kill the acceptor thread.
            val authorized = try { running && allowedClient(client.inetAddress) }
                catch (_: Exception) { false }
            if (!authorized || !permits.tryAcquire()) {
                client.closeQuietly()
                continue
            }
            clients.add(client)
            try {
                workers.execute {
                    try { handle(client) } finally {
                        clients.remove(client)
                        client.closeQuietly()
                        permits.release()
                    }
                }
            } catch (_: Exception) {
                clients.remove(client)
                client.closeQuietly()
                permits.release()
            }
        }
    }

    private fun handle(client: Socket) {
        client.use { c ->
            c.soTimeout = minOf(15_000, headerBudgetMillis.toInt())
            val incoming = BufferedInputStream(c.getInputStream())
            // Never append a synthetic 502 to an upstream response already in flight.
            // Flush bytes to the socket as they are forwarded. A BufferedOutputStream here
            // could hide a partial upstream response from committed detection and cause a
            // synthetic 502 to be concatenated to that response on an I/O error.
            val downstream = CommitTrackingOutputStream(c.getOutputStream())
            val outgoing: OutputStream = downstream
            try {
                // Monotonic overall header budget defeats slow-drip requests that
                // would bypass per-read socket timeouts indefinitely.
                val headerDeadline = System.nanoTime() +
                    TimeUnit.MILLISECONDS.toNanos(headerBudgetMillis)
                val first = readCrlfLine(c, incoming, 4096, headerDeadline)
                val start = first.split(' ')
                if (start.size != 3 || start.any { it.isEmpty() } || start[2] != "HTTP/1.1") {
                    return respond(outgoing, 400, "Bad Request")
                }
                val method = start[0] // case sensitive: HTTP methods are case sensitive
                val target = start[1]
                val headers = ArrayList<Pair<String, String>>()
                var total = first.length
                while (true) {
                    val line = readCrlfLine(c, incoming, 4096, headerDeadline)
                    total += line.length + 2
                    if (total > 16_384) return respond(outgoing, 431, "Headers Too Large")
                    if (line.isEmpty()) break
                    if (headers.size >= 64) return respond(outgoing, 431, "Headers Too Large")
                    val colon = line.indexOf(':')
                    if (colon <= 0) return respond(outgoing, 400, "Bad Header")
                    val key = line.substring(0, colon)
                    val value = line.substring(colon + 1).trim()
                    if (!key.matches(HEADER_NAME)) return respond(outgoing, 400, "Bad Header")
                    headers.add(key to value)
                }
                c.soTimeout = 15_000 // payload and upstream handling use a separate idle budget
                // Reject ambiguous transfer framing; relay only a bounded, fixed-length body.
                // Chunked transfer-encoding is not supported in M5 (do not guess its length).
                val lengths = headers.filter { it.first.equals("Content-Length", true) }
                if (lengths.size > 1 || headers.any { it.first.equals("Transfer-Encoding", true) })
                    return respond(outgoing, 400, "Ambiguous Message Framing")
                if (headers.any { it.first.equals("Expect", true) })
                    return respond(outgoing, 417, "Expectation Failed")
                val rawLength = lengths.singleOrNull()?.second
                if (rawLength != null && (rawLength.isEmpty() || rawLength.any { it !in '0'..'9' }))
                    return respond(outgoing, 400, "Invalid Content-Length")
                val length = rawLength?.toLongOrNull() ?: if (lengths.isEmpty()) 0L else -1L
                if (length < 0L || length > MAX_REQUEST_BODY_BYTES)
                    return respond(outgoing, 413, "Unsupported Request Length")
                if (method == "CONNECT") {
                    if (length != 0L) return respond(outgoing, 400, "CONNECT Body Rejected")
                    return handleConnect(c, incoming, outgoing, target)
                }
                if (method !in ALLOWED_HTTP_METHODS) return respond(outgoing, 501, "Not Implemented")
                if ((method == "GET" || method == "HEAD") && length != 0L)
                    return respond(outgoing, 400, "GET/HEAD Body Rejected")
                handleHttp(incoming, outgoing, method, target, headers, length)
            } catch (_: InvalidHttp) {
                if (!downstream.committed) respondSafely(outgoing, 400, "Bad Request")
            } catch (_: java.net.SocketTimeoutException) {
                if (!downstream.committed) respondSafely(outgoing, 408, "Request Timeout")
            } catch (_: IOException) {
                if (!downstream.committed) respondSafely(outgoing, 502, "Bad Gateway")
            } catch (_: Exception) {
                if (!downstream.committed) respondSafely(outgoing, 500, "Internal Error")
            }
        }
    }

    private fun handleConnect(client: Socket, incoming: InputStream, outgoing: OutputStream, target: String) {
        val destination = parseAuthority(target) ?: return respond(outgoing, 400, "Bad Authority")
        var established = false
        try {
            withTrackedUpstream(destination.first, destination.second) { upstreamSocket ->
                client.soTimeout = 120_000
                upstreamSocket.soTimeout = 120_000
                outgoing.write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray(Charsets.US_ASCII))
                outgoing.flush()
                established = true
                // Once 200 is sent, no synthetic HTTP status may be added to TLS bytes.
                val upload = Thread({
                    try { transfer(incoming, upstreamSocket.getOutputStream()) } catch (_: IOException) { }
                    try { upstreamSocket.shutdownOutput() } catch (_: IOException) { }
                }, "netshare-connect-upload").apply { isDaemon = true }
                upload.start()
                try { transfer(upstreamSocket.getInputStream(), outgoing) } catch (_: IOException) { }
                try { client.shutdownOutput() } catch (_: IOException) { }
                try { upload.join(2000) } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                }
            }
        } catch (e: IOException) {
            if (!established) throw e
        } catch (e: RuntimeException) {
            if (!established) throw e
        }
    }

    private fun handleHttp(incoming: InputStream, outgoing: OutputStream, method: String, target: String,
                           headers: List<Pair<String, String>>, bodyLength: Long) {
        val uri = try { URI(target) } catch (_: Exception) { return respond(outgoing, 400, "Bad URL") }
        if (uri.scheme != "http" || uri.host.isNullOrBlank() || uri.rawUserInfo != null ||
            uri.rawFragment != null || uri.rawAuthority == null) return respond(outgoing, 400, "HTTP URL Required")
        val destPort = if (uri.port == -1) 80 else uri.port
        if (destPort !in 1..65535) return respond(outgoing, 400, "Bad Port")
        val path = (uri.rawPath.takeUnless { it.isNullOrEmpty() } ?: "/") +
            (uri.rawQuery?.let { "?$it" } ?: "")
        // Both standard Connection and legacy Proxy-Connection may nominate
        // headers as hop-by-hop. Never let a client nominate framing or routing
        // fields such as Content-Length or Host: stripping those fields while
        // relaying a request body can desynchronize the upstream connection.
        // Even though we generate Host from the absolute URL, ambiguous duplicate
        // Host headers can trigger differences between intermediaries. Reject them.
        val hostHeaders = headers.filter { it.first.equals("Host", true) }
        if (hostHeaders.size > 1 || hostHeaders.any { it.second.isBlank() })
            return respond(outgoing, 400, "Invalid Host Header")
        val connectionHeaders = headers.filter {
            it.first.equals("Connection", true) || it.first.equals("Proxy-Connection", true)
        }.flatMap { it.second.split(',') }.map { it.trim().lowercase() }
        if (connectionHeaders.any { !it.matches(HEADER_NAME) || it in PROTECTED_FIELDS }) {
            return respond(outgoing, 400, "Unsafe Connection Header")
        }
        val exclude = HOP_BY_HOP + connectionHeaders.toSet()
        withTrackedUpstream(uri.host, destPort) { remote ->
            remote.soTimeout = 30_000
            val remoteOut = BufferedOutputStream(remote.getOutputStream())
            remoteOut.write("$method $path HTTP/1.1\r\n".toByteArray(Charsets.ISO_8859_1))
            headers.forEach { (name, value) ->
                if (name.lowercase() !in exclude) {
                    remoteOut.write("$name: $value\r\n".toByteArray(Charsets.ISO_8859_1))
                }
            }
            remoteOut.write("Host: ${uri.rawAuthority}\r\nConnection: close\r\n\r\n".toByteArray(Charsets.ISO_8859_1))
            if (bodyLength != 0L) copyExactly(incoming, remoteOut, bodyLength)
            remoteOut.flush()
            transfer(remote.getInputStream(), outgoing)
            outgoing.flush()
        }
    }

    private inline fun <T> withTrackedUpstream(host: String, port: Int, block: (Socket) -> T): T {
        val socket = upstream.connect(host, port)
        remoteSockets.add(socket)
        try {
            check(running) { "Proxy stopped during upstream setup" }
            return socket.use(block)
        } finally {
            remoteSockets.remove(socket)
            socket.closeQuietly()
        }
    }

    private fun readCrlfLine(client: Socket, stream: InputStream, maxLen: Int, deadlineNanos: Long): String {
        val bytes = ByteArrayOutputStream()
        while (bytes.size() <= maxLen) {
            val left = deadlineNanos - System.nanoTime()
            if (left <= 0L)
                throw java.net.SocketTimeoutException("Header deadline exceeded")
            // Per-read idle timeouts alone let a slow peer exceed the total
            // header budget. Restrict each socket read to the remaining budget.
            // SO_TIMEOUT is integer milliseconds (0 would disable it).
            client.soTimeout = minOf(15_000L,
                maxOf(1L, TimeUnit.NANOSECONDS.toMillis(left))).toInt()
            val value = stream.read()
            if (System.nanoTime() - deadlineNanos >= 0L)
                throw java.net.SocketTimeoutException("Header deadline exceeded")
            if (value < 0) throw InvalidHttp()
            if (value == 10) {
                val raw = bytes.toByteArray()
                if (raw.isEmpty() || raw.last() != 13.toByte()) throw InvalidHttp()
                val result = String(raw, 0, raw.size - 1, Charsets.ISO_8859_1)
                if (result.any { it.code < 32 && it != '\t' || it.code == 127 }) throw InvalidHttp()
                return result
            }
            bytes.write(value)
        }
        throw InvalidHttp()
    }

    private fun parseAuthority(s: String): Pair<String, Int>? {
        if (s.any { it.isWhitespace() || it.code < 32 }) return null
        val uri = try { URI("http://$s") } catch (_: Exception) { return null }
        if (uri.rawUserInfo != null || uri.rawPath?.isNotEmpty() == true ||
            uri.rawQuery != null || uri.rawFragment != null || uri.rawAuthority != s) return null
        val host = uri.host ?: return null
        if (uri.port !in 1..65535) return null
        return host to uri.port
    }

    private fun respond(outgoing: OutputStream, status: Int, message: String) {
        outgoing.write("HTTP/1.1 $status $message\r\nContent-Length: 0\r\nConnection: close\r\n\r\n"
            .toByteArray(Charsets.US_ASCII))
        outgoing.flush()
    }
    private fun respondSafely(outgoing: OutputStream, status: Int, message: String) {
        try { respond(outgoing, status, message) } catch (_: Exception) { }
    }
    private fun copyExactly(source: InputStream, sink: OutputStream, length: Long) {
        var remaining = length
        val buffer = ByteArray(16_384)
        while (remaining > 0L) {
            val received = source.read(buffer, 0, minOf(remaining, buffer.size.toLong()).toInt())
            if (received < 0) throw IOException("Client body truncated")
            if (received == 0) continue
            sink.write(buffer, 0, received)
            remaining -= received
        }
    }

    private fun transfer(source: InputStream, sink: OutputStream) {
        val buffer = ByteArray(16_384)
        while (true) {
            val count = source.read(buffer)
            if (count < 0) break
            sink.write(buffer, 0, count)
            sink.flush()
        }
    }
    @Synchronized override fun close() {
        if (closed) return
        closed = true
        running = false
        server?.closeQuietly()
        clients.forEach { it.closeQuietly() }
        remoteSockets.forEach { it.closeQuietly() }
        workers.shutdownNow()
        try {
            workers.awaitTermination(2, TimeUnit.SECONDS)
            acceptor?.join(1000)
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        }
    }

    private class InvalidHttp: IOException()

    private class CommitTrackingOutputStream(private val delegate: OutputStream) : OutputStream() {
        @Volatile var committed: Boolean = false
            private set
        override fun write(value: Int) { committed = true; delegate.write(value) }
        override fun write(data: ByteArray, offset: Int, length: Int) {
            if (length > 0) committed = true
            delegate.write(data, offset, length)
        }
        override fun flush() = delegate.flush()
        override fun close() = delegate.close()
    }
    companion object {
        private const val MAX_REQUEST_BODY_BYTES = 8L * 1024L * 1024L
        private val ALLOWED_HTTP_METHODS = setOf("GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS")
        private val HEADER_NAME = Regex("[!#\\$%&'*+.^_`|~0-9A-Za-z-]+")
        private val HOP_BY_HOP = setOf("host", "connection", "proxy-connection", "proxy-authorization",
            "proxy-authenticate", "keep-alive", "te", "trailer", "transfer-encoding", "upgrade")
        private val PROTECTED_FIELDS = setOf("host", "content-length", "transfer-encoding", "expect")
    }
}

private fun Socket.closeQuietly() { try { close() } catch (_: IOException) { } }
private fun ServerSocket.closeQuietly() { try { close() } catch (_: IOException) { } }
