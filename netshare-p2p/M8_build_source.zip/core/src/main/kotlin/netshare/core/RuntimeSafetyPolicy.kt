package netshare.core

/**
 * Fail-closed policy used by read-only runtime monitoring. State can be observed,
 * but observing these booleans does NOT prove firmware Tethering/SoftAP absence.
 */
object RuntimeSafetyPolicy {
    fun mayKeepRunning(role: P2pRole, p2pAddressStillPresent: Boolean,
                       sameValidatedCellularNetwork: Boolean): Boolean =
        role == P2pRole.GROUP_CLIENT && p2pAddressStillPresent && sameValidatedCellularNetwork
}
